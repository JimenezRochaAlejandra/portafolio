
  <script src="https://www.gstatic.com/firebasejs/3.5.2/firebase.js"></script>
  <script>
  	 var config = {
    apiKey: "AIzaSyCPs_4lN_dXX0fZr09M888HCs1QZvN82XU",
    authDomain: "keyito.firebaseapp.com",
    databaseURL: "https://keyito.firebaseio.com",
    projectId: "keyito",
    storageBucket: "keyito.appspot.com",
    messagingSenderId: "589526498841",
    appId: "1:589526498841:web:5c79f5d25770b77d5af488"
  };
  firebase.initializeApp(config);
var authService = firebase.auth();

			
// accedo al servicio de autenticación
//$email='diego@hotmail.com';
//$password='123433';
  
$email ='<?=$_POST['usuario']?>'
			$password = '<?=$_POST['contrasena']?>';


////*********** crear usuario**************/////////77
/*authService.createUserWithEmailAndPassword($email, $password)

.then(function (user) {
		console.log('¡Creamos al usuario!');
	})
	.catch(function (error) {
		console.error(error)
	});

  ****************************************************/

authService.signInWithEmailAndPassword($email, $password).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  if (errorCode == 'auth/wrong-password') {
    alert('Contraseña incorrecta. Intentelo de nuevo.');
    window.location = "http://localhost/login_social/login.php";
  }else if (errorCode=='auth/too-many-requests') {
  	alert('Demasiados intentos de inicio de sesión fallidos. Por favor, inténtelo de nuevo más tarde.');
    window.location = "http://localhost/login_social/login.php";
  }else if (errorCode=='auth/invalid-email') {
  	alert('La dirección de correo electrónico no es valida.');
    window.location = "http://localhost/login_social/login.php";
  }else if(errorCode=='auth/user-not-found'){
  	alert('Usuario no registrado. El usuario puede haber sido eliminado');
    window.location = "http://localhost/login_social/login.php";
  } else if(errorCode=='auth/user-disabled'){
  	alert('La cuenta de usuario ha sido deshabilitada por un administrador');
    window.location = "http://localhost/login_social/login.php";
  }else if(errorCode=="auth/network-request-failed"){
  	alert('Conexión Fallida');
    window.location = "http://localhost/keyito/login.php";
  }
  else {
    alert(errorCode);
   window.location = "http://localhost/keyito/login.php";
  }
  
});

authService.onAuthStateChanged(function(user) {
  if (user) {
  	if((user.uid)==("ffqlOXIwatbjPCcZYoj08VmUJXt2")){ //administracion admin@gmail.com
  	console.log(user.email);
 window.location = "http://localhost/keyito/vista_mapa.php";
} else {
	console.log(user.email);
  	console.log("mapa usuario");
  	window.location = "http://localhost/keyito/vista_mapaUsuario.php" + "?corr=" + user.email;

      } 
 	  }else {
 	console.log(user.email);
   console.log('not logged in')

  }
  
});


  </script>
