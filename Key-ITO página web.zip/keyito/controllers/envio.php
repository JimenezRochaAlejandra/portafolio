<?php
	
	session_start();

	require_once ('../vendor/autoload.php');
	require_once('../app/auth/auth.php');

	if (Auth::isLogin()){
		if ($_POST) {
		print_r($_POST);
		$id_user = $_SESSION['user']['id'];
		$nombre = $_POST['nombre'];
		$correo = $_POST['correo'];
		$direccion = $_POST['direccion'];

		$enlace = mysqli_connect("localhost", "root", "", "sociallogin");
		 
		if (!$enlace) {
		    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
		    echo "error de depuración: " . mysqli_connect_errno() . PHP_EOL;
		    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
		    exit;
		}
		
				mysqli_query($enlace,"UPDATE remitente SET remitente = '$nombre', correo = '$correo'where id_user = ".$id_user);

				mysqli_query($enlace,"INSERT INTO envio (remitente) VALUES('$nombre')");

				mysqli_close($enlace);

			header('Location: ../vista_destinatario.php');

		}else {
		echo "No estoy recibiendo ninguna peticion";
		}
	}else{
		header('Location: http://localhost/uber/vista_remitente.php ');
	}

?>