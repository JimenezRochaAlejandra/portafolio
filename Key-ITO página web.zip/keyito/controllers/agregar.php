
  <script src="https://www.gstatic.com/firebasejs/3.5.2/firebase.js"></script>
  <script>
  	 var config = {
    apiKey: "AIzaSyCPs_4lN_dXX0fZr09M888HCs1QZvN82XU",
    authDomain: "keyito.firebaseapp.com",
    databaseURL: "https://keyito.firebaseio.com",
    projectId: "keyito",
    storageBucket: "keyito.appspot.com",
    messagingSenderId: "589526498841",
    appId: "1:589526498841:web:5c79f5d25770b77d5af488"
  };
  firebase.initializeApp(config);
//var authService = firebase.auth();
var database = firebase.database();
			
// accedo al servicio de autenticación

  
$clave ='<?=$_POST['clave']?>'
$lat= ''
$longi =''

  firebase.database().ref('Usuario/' ).once('value', function(snapshot) {
    var val;
  snapshot.forEach(function(childSnapshot) {
    var childKey = childSnapshot.key;
     childData = childSnapshot.val();
     console.log("chinl... "+childData.usu );
    val=parseInt(childData.usu)+1;
  });
    firebase.database().ref('Usuario/' + ('usuario'+val)).set({
    clave: $clave,
    lat: $lat,
    longi:$longi,
    usu:val.toString()
    
  }, function(error) {
    if (error) {
       alert("Error:dispositivo no registrado");
   window.location = "http://localhost/keyito/vista_mapa.php";
    } else {
       alert("Dispositivo Registrado");
   window.location = "http://localhost/keyito/vista_mapa.php";
    }
  });
});



  </script>