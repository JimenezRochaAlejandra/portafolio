<?php
	
	session_start();

	require_once ('../vendor/autoload.php');
	require_once('../app/auth/auth.php');

	if (Auth::isLogin()){
		if ($_POST) {
		print_r($_POST);
		$nombreu = $_SESSION['user']['name'];
		$nombre = $_POST['nombre'];

		$enlace = mysqli_connect("localhost", "root", "", "sociallogin");
		 
		if (!$enlace) {
		    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
		    echo "error de depuración: " . mysqli_connect_errno() . PHP_EOL;
		    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
		    exit;
		}
		
				mysqli_query($enlace,"UPDATE envio SET destinatario = '$nombre' where remitente = '$nombreu'");

				mysqli_close($enlace);

			header('Location: ../vista_mapa.php');

		}else {
		echo "No estoy recibiendo ninguna peticion";
		}
	}else{
		header('Location: http://localhost/uber/vista_destinatario.php ');
	}

?>