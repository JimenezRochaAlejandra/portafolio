 <script src="https://www.gstatic.com/firebasejs/3.5.2/firebase.js"></script>
  <script>
  	 var config = {
    apiKey: "AIzaSyCPs_4lN_dXX0fZr09M888HCs1QZvN82XU",
    authDomain: "keyito.firebaseapp.com",
    databaseURL: "https://keyito.firebaseio.com",
    projectId: "keyito",
    storageBucket: "keyito.appspot.com",
    messagingSenderId: "589526498841",
    appId: "1:589526498841:web:5c79f5d25770b77d5af488"
  };
  firebase.initializeApp(config);
var authService = firebase.auth();

			
// accedo al servicio de autenticación
//$email='diego@hotmail.com';
//$password='123433';
  


////*********** crear usuario**************/////////77
/*authService.createUserWithEmailAndPassword($email, $password)

.then(function (user) {
		console.log('¡Creamos al usuario!');
	})
	.catch(function (error) {
		console.error(error)
	});

  ****************************************************/
authService.signOut().then(function() {
   console.log("deslogeado");
    window.location = "http://localhost/keyito/login.php";
}).catch(function(error) {
  // An error happened.
   console.log("no se deslogeo");
window.location = "http://localhost/keyito/vista_mapa.php"; 
});
 
 /** authService.onAuthStateChanged(firebaseUser => {
  if (firebaseUser) {
    console.log(firebaseUser.email);
   console.log('logged in');
 //window.location = "http://localhost/login_social/vista_mapa.php"; 
  } 
  else {
   // console.log(firebaseUser.email);
   console.log('not logged in')
  // location.href='http://localhost/login_social/login.php';
 
  }
});*/


  </script>
