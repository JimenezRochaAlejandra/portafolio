/*pk.eyJ1Ijoic3lsdmlhdmVsc2FuIiwiYSI6ImNqdG52dGpzdzAwaWc0OWxhdngxYjV2OW8ifQ.Y6hn5mhi7lv7IsW3RI_Drw*/

mapboxgl.accessToken = 'pk.eyJ1Ijoic3lsdmlhdmVsc2FuIiwiYSI6ImNqdG52cmY1ODRiNWk0Ym8zYmV3a3BxbGQifQ.e-gYvqflmX8UUEhkqG8nig';

//Posicion del mapa
var map = new mapboxgl.Map({
	container: 'map',
	style: 'mapbox://styles/mapbox/streets-v11',
	//       Longitud   , Latitud
	center: [-96.7256205,17.0615388],
	zoom: 15
	});

//Marcador
var element = document.createElement('div')
element.className = 'marker'

let marker = new mapboxgl.Marker(element)
	.setLngLat({
		lng: -96.7256205,
		lat: 17.0615388
	})
	.addTo(map);

//Trazo de ruta

    var mapruta = new mapboxgl.Map({
        container: 'mapruta',
        style: 'mapbox://styles/mapbox/streets-v11',
        center: [-96.7256205,17.0615388],
        zoom: 15
    });

    mapruta.addControl(new MapboxDirections({
        accessToken: mapboxgl.accessToken
    }), 'top-left');