<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8' />
    <title>Rutas Emergentes</title>
    <meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
    <script src='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.js'></script>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.css' rel='stylesheet' />
    <link rel="stylesheet" href="main.css">
</head>
<body>
        <script src='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.0.0/mapbox-gl-directions.js'></script>
        <link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.0.0/mapbox-gl-directions.css' type='text/css' />
        <div id='map'></div>

        <script>
                mapboxgl.accessToken = 'pk.eyJ1Ijoic3lsdmlhdmVsc2FuIiwiYSI6ImNqdG52cmY1ODRiNWk0Ym8zYmV3a3BxbGQifQ.e-gYvqflmX8UUEhkqG8nig';
                var map = new mapboxgl.Map({
                    container: 'map',
                    style: 'mapbox://styles/mapbox/streets-v11',
                    center: [-96.7256205,17.0615388],
                    zoom: 15
                });

                map.addControl(new MapboxDirections({
                    accessToken: mapboxgl.accessToken
                }), 'top-left');
        </script>
</body>
</html>