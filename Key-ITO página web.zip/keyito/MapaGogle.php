
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 425px;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #floating-panel {
        
        background-image: url("assets/fonts/fondo2.jpg");
        position: absolute;
        top: 10px;
        left: 14%;
        z-index: 5;
        background-color: #fff;
        padding: 5px;
        border: 1px solid #999;
        
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
      }

      .letras{
        color: white;
      }
    </style>


  </head>
  <body  background="assets/fonts/fondo2.jpg">
    <script type="text/javascript"></script>
    <div id="floating-panel">
     
    <b>Origen: </b>
    <input id="inicio" type="" name="" class="form-control" >
    <b>Destino: </b>
    <input id="fin" type="" name="" class="form-control" >
    </div>

    <div id="map" align="center"></div>
    <script>
      function initMap() {
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 9,
          center: {lat: 17.07600980620042, lng: -96.74481654005221 } //ubicacion de Oaxaca
        });
        directionsDisplay.setMap(map);

        var onChangeHandler = function() {
          calculateAndDisplayRoute(directionsService, directionsDisplay);
          
        };
        document.getElementById('inicio').addEventListener('change', onChangeHandler);
        document.getElementById('fin').addEventListener('change', onChangeHandler);
        
       // Definir el símbolo, usando una de las rutas predefinidas ('CIRCLE') -----creando el circulo
        // proporcionado por la API de JavaScript de Google Maps.
        var lineSymbol = {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 8,
          strokeColor: '#393'
        };
  
// Cree la polilínea y agregue el símbolo a través de la propiedad 'iconos'.

        var line = new google.maps.Polyline({
          path: [{lat: 17.079154, lng: -96.744439}, {lat: 17.061093, lng: -96.727295}],
          icons: [{
            icon: lineSymbol,
            offset: '100%'
                  }],
          map: map
        });

        animateCircle(line);//----------------------------------------------------------termina la animacion
      } //termina la funcion de crear Mapa


        // Use la función DOM setInterval () para cambiar el desplazamiento del símbolo----------inicia 
      // a intervalos fijos.
      function animateCircle(line) {
          var count = 0;
          window.setInterval(function() {
            count = (count + 1) % 200;

            var icons = line.get('icons');
            icons[0].offset = (count / 2) + '%';
            line.set('icons', icons);
        }, 300);
      }  //-----------------------------------------termina la funcion de animar


      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
        directionsService.route({
          origin: document.getElementById('inicio').value,
          destination: document.getElementById('fin').value,
           optimizeWaypoints: true,
          travelMode: 'DRIVING'

        }, function(response, status) {
          if (status === 'OK') {

             // Aqui con el response podemos acceder a la distancia como texto 
                
                var km =response.routes[0].legs[0].distance.text;
                console.log(km);

                // Obtenemos la distancia como valor numerico en metros 
                var metross = parseFloat(response.routes[0].legs[0].distance.value);
                var comision =0.0125;
                var total = parseFloat(comision * metross);
                console.log("total a pagar = $ "+total);

            directionsDisplay.setDirections(response);
            // Obtener la duración para la primer ruta
    var route = response.routes[0];
    var duration = 0;

    // Iteramos todos los legs de la ruta
    route.legs.forEach(function (leg) {
      // Sumamos la duracion de cada uno
      // La duración esta en segundos.
      duration += leg.duration.value;

    });
   
    ///
    
    ///

    // Por ejemplo: imprimimos el resultado en DOMElement con id 'duracion'
    

    var  minutos =parseFloat(duration/60);
     console.log(minutos+ " minutos");
     document.getElementById('tiempo').innerHTML = "Minutos: " + minutos+ " minutos";
     document.getElementById('kilometros').innerHTML = "Distancia en kilometros:__ "+ km;
     document.getElementById('mets').innerHTML = "Distancia en mts:__ "+ metross+ " mts";
    document.getElementById('tl').innerHTML = "Total a pagar $: "+ total+ " pesos";

          } else {
           // window.alert('Directions request failed due to ' + status);
          }
        });

      }

    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC9bYfEezaRArZJELDisPt73WUz-oysTs&callback=initMap">
    </script>

   <h4 id="kilometros" class="letras">
       Distancia e kilometros:__
  </h4>
  <h4 id="mets" class="letras" >
       Distancia en mts:__
  </h4>
  
  <h4 id="tiempo" class="letras">
     Minutos:__
  </h4>
   <h4 id="tl" class="letras" >
     total a pagar $:__
  </h4>
     

     
      
    <br>
      
     <div align=" center" >
        <script src="https://www.paypal.com/sdk/js?client-id=sb"></script>
    <script>paypal.Buttons().render('body');</script>
     </div>
    <div >
            
       <button class="btn btn-warning" onclick="location.href='http://localhost/login_social/stripe/index.php'">PROCEDER A PAGAR </button>
    </div>

     
  </body>
</html>
