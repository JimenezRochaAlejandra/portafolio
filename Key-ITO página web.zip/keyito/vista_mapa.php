<?php
	session_start();

	require_once ('vendor/autoload.php');
	require_once('app/auth/auth.php');

?>

<!DOCTYPE html>
<html>
<head>
	
				<title>Bienvenido a KeyITO</title>
	

	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-social.css">
	<script src="assets/js/jquery.js" charset="utf-8"></script>
	<meta charset='utf-8' />
    <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
	<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />

  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-app.js"></script>

  <!-- Add Firebase products that you want to use -->
  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-auth.js"></script>
  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-database.js"></script>
	<style type="text/css">
		body {
			background-image: url("assets/fonts/fondoweb.jpg");
			margin: 100px;
			width: 100px;
			<?php if (Auth::isLogin()): ?>
				margin-left: 50px;
				margin-top: 30px;
			<?php else: ?>
			<?php Auth::getUserAuth();?>
				margin-left: 450px;
				margin-top: 150px;
				text-align: center;
			<?php endif; ?>
		}
		#contenedorLogin{
		margin-left: 10px;
		margin-top: 10px;
        width: 1470px;
        height: auto;
        background-color: #E4ECED;
        //font-family: "Verdana",Verdana,Sans-serif;
        }
		#contenedorLogout{
        width: 450px;
        height: 280px;
        background-color: white;
        font-family: "Verdana",Verdana,Sans-serif;
        font-size: 30px;
      	}

     #right-panel {
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
        float: right;
        width: 40%;
        height: 100%;
      }

      #right-panel select, #right-panel input {
        font-size: 14px;
      }

      #right-panel select {
        width: 100%;
      }

      #right-panel i {
        font-size: 12px;
      }
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #map {
        height: 100%;
        float: center;
        width: 1440px;
        height: 650px;
      }
	</style>
</head>
<body>

				<div class="container" id="contenedorLogin">
					<div class="form-row">
         
            
				          <!--Mapa de Google-->
				          <div class="col-md-12">
				          	<div id="map" class="col-md-2"></div>
						    
						    <script>

 var firebaseConfig = {
    apiKey: "AIzaSyCPs_4lN_dXX0fZr09M888HCs1QZvN82XU",
    authDomain: "keyito.firebaseapp.com",
    databaseURL: "https://keyito.firebaseio.com",
    projectId: "keyito",
    storageBucket: "keyito.appspot.com",
    messagingSenderId: "589526498841",
    appId: "1:589526498841:web:5c79f5d25770b77d5af488"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  var  database= firebase.database();
  
                      var childData;
                      var marker1 ;
                      
					var authService = firebase.auth();
					authService.onAuthStateChanged(firebaseUser => {
  if (firebaseUser) {
  	console.log(firebaseUser.email);
  	console.log("mapa Admin");
  	console.log(firebaseUser.uid);
   console.log('logged in');
 
  } 
  else {
  	console.log(firebaseUser.email);
   console.log('not logged in')
  // location.href='http://localhost/login_social/login.php';

  }
});	 
						      function initMap() {
						        var map = new google.maps.Map(document.getElementById('map'), {
						          zoom: 7,
						          center: {lat: 18.345, lng: -99.46}  // Australia.
						        });

						        var directionsService = new google.maps.DirectionsService;
						        var directionsDisplay = new google.maps.DirectionsRenderer({
						          draggable: true,
						          map: map,
						          
						        });

						        directionsDisplay.addListener('directions_changed', function() {
						          computeTotalDistance(directionsDisplay.getDirections());
						        });
                             
                              

						        
						        ///agregacion de puntos de firebase 
firebase.database().ref('Usuario/' ).once('value', function(snapshot) {
  snapshot.forEach(function(childSnapshot) {
    var childKey = childSnapshot.key;
     childData = childSnapshot.val();
    
    console.log("chinl... "+childKey );
     console.log("chinl... "+childData.lat );
      marker1 = new google.maps.Marker({
 position: {lat: parseFloat(childData.lat), lng: parseFloat(childData.longi)},
 draggable: false,
  title: 'Usuario: '+childData.usu
 });
      marker1.setMap(map);
    // ...
  });
});
						       
						      }

						      function displayRoute(origin, destination, service, display) {

						        service.route({
						          origin: origin,
						          destination: destination,
						          travelMode: 'DRIVING',
						          avoidTolls: true
						        }, function(response, status) {
						          if (status === 'OK') {
						            display.setDirections(response);

						            //console.log(origin_location);
						          } else {
						            alert('Could not display directions due to: ' + status);
						          }
						        });

                                   
						      }


						      var inicio = false;
						      var destino = false;
						      var costo = false;
						      function computeTotalDistance(result) {
						        var total = 0;
						        var myroute = result.routes[0];
						        for (var i = 0; i < myroute.legs.length; i++) {
						          total += myroute.legs[i].distance.value;
						        }
						        var tiempo = 0;
						        tiempo = result.routes[0].legs[0].duration.value;
						        tiempo = tiempo/60;
						        totalkm = total / 1000;
						        costo = totalkm*4.50;
						        document.getElementById('totalkm').innerHTML = totalkm + ' km';
						        document.getElementById('total').innerHTML = total + ' m';
						        document.getElementById('costo').innerHTML = costo + ' pesos';
						        document.getElementById('tiempo').innerHTML = tiempo + ' min';
                             
                             
						        inicio = result.routes[0].legs[0].start_address;
						        destino = result.routes[0].legs[0].end_address;
                                 
                                   writeUserData(1, inicio, destino,costo,totalkm);


						        //Consolita
						        console.clear();
						        console.log(result.routes[0].legs[0].start_address);
						        console.log(result.routes[0].legs[0].end_address);
						         
						        
						      }

						      
						      function writeUserData(userId, origen, destino,costo,distancia) {
  firebase.database().ref('coordenadas/' ).set({
    origen1: origen,
    destino1: destino,
    costo1:costo,
    distancia1:distancia,

  });
}

                      

						      //Mandar al post
						       	function llamadaalpost(){
						       	var data = {};
						        data.inicio = inicio;
						        data.destino = destino;
						        data.costo = costo;
						     //  writeUserData(1, inicio, destino);
						        var url = "probandopost.php";
						        $.ajax({
							        method: 'POST',
							        url: url,
							        data: data,   
							        //acá están todos los parámetros (valores a enviar) del POST
							        success: function(response){
							            // Se ejecuta al finalizar
							            //   mostrar si está OK en consola
							            //console.log(response);
							            window.location = "http://localhost/login_social/vista_prepago.php"; 
							        }
							    });
						       	}


						       	


						    </script>
						    
						    <script async defer
						    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC9bYfEezaRArZJELDisPt73WUz-oysTs&callback=initMap">
						    </script>
				          </div>

				          <!--Botones parte baja-->
				          
				        
		     	  		 
            <div class="btn-group">
                <div class="btn-group"  >
			         	 	<a href="estadisticas.php" class="btn btn-info" style="margin-top: 10px;margin-right: 10px margin-bottom: 5px; font-size: 20px">Incidencias</a>
			     	  	  </div>

			     	  	  <div class="btn-group" >
			         	 	<a href="agregar_dispositivo.php" class="btn btn-info" style="margin-top: 10px;margin-bottom: 10px; font-size: 20px;margin-left: 200px;">Registrar dispositivo</a>
			     	  	  </div>

						  <div class="btn-group" >
		         	 		<a href="logout.php" class="btn btn-danger" style="margin-top: 10px;margin-bottom: 10px; font-size: 20px;margin-left: 200px;">Cerrar Sesion</a>
		     	  		  </div>
            </div>
       
                             
		     	  		 

					</div>
				</div>
		
	
</body>
</html>