<?php
	session_start();

	require_once ('vendor/autoload.php');
	require_once('app/auth/auth.php');

?>

<!DOCTYPE html>
<html>
<head>
	
				<title>Bienvenido a KeyITO</title>
	

	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-social.css">
	<script src="assets/js/jquery.js" charset="utf-8"></script>
	<meta charset='utf-8' />
    <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
	<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />

  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-app.js"></script>

  <!-- Add Firebase products that you want to use -->
  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-auth.js"></script>
  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-database.js"></script>
	<style type="text/css">
		body {
			background-image: url("assets/fonts/fondoweb.jpg");
			margin: 100px;
			width: 100px;
			<?php if (Auth::isLogin()): ?>
				margin-left: 50px;
				margin-top: 30px;
			<?php else: ?>
			<?php Auth::getUserAuth();?>
				margin-left: 450px;
				margin-top: 150px;
				text-align: center;
			<?php endif; ?>
		}
		#contenedorLogin{
		margin-left: 10px;
		margin-top: 10px;
        width: 1470px;
        height: auto;
        background-color: #E4ECED;
        //font-family: "Verdana",Verdana,Sans-serif;
        }
		#contenedorLogout{
        width: 450px;
        height: 280px;
        background-color: white;
        font-family: "Verdana",Verdana,Sans-serif;
        font-size: 30px;
      	}

     #right-panel {
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
        float: right;
        width: 40%;
        height: 100%;
      }

      #right-panel select, #right-panel input {
        font-size: 14px;
      }

      #right-panel select {
        width: 100%;
      }

      #right-panel i {
        font-size: 12px;
      }
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #map {
        height: 100%;
        float: center;
        width: 1440px;
        height: 650px;
      }
	</style>
</head>
<body>

				<div class="container" id="contenedorLogin">
					<div class="form-row">
        
				          <div class="col-md-12">
				          	<div id="map" class="col-md-2"></div>
						    		       	<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
<div id="plotlyChart"></div>

						    <script>

						    var firebaseConfig = {
    apiKey: "AIzaSyCPs_4lN_dXX0fZr09M888HCs1QZvN82XU",
    authDomain: "keyito.firebaseapp.com",
    databaseURL: "https://keyito.firebaseio.com",
    projectId: "keyito",
    storageBucket: "keyito.appspot.com",
    messagingSenderId: "589526498841",
    appId: "1:589526498841:web:5c79f5d25770b77d5af488"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  var  database= firebase.database();
  
                      var childData;
                      var marker1 ;
                      
					var authService = firebase.auth();
					authService.onAuthStateChanged(firebaseUser => {
  if (firebaseUser) {
  	console.log(firebaseUser.email);
  	console.log("mapa Admin");
  	console.log(firebaseUser.uid);
   console.log('logged in');
 
  } 
  else {
  	console.log(firebaseUser.email);
   console.log('not logged in')
  // location.href='http://localhost/login_social/login.php';

  }
});	 
						   var geocoding=' ';
						  
						  var dat1=[]; 
						   var dat2=[];      
						        ///agregacion de puntos de firebase 
firebase.database().ref('Usuario/' ).once('value', function(snapshot) {
  snapshot.forEach(function(childSnapshot) {
    var childKey = childSnapshot.key;
     childData = childSnapshot.val();
    
    console.log("chinl... "+childKey );
     console.log("chinl... "+childData.lat );
     console.log("chinl... "+childData.longi );

     //var miDireccion = new google.maps.LatLng(childData.lat, childData.longi);
     //console.log(miDireccion);
     geocoding ='https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyDC9bYfEezaRArZJELDisPt73WUz-oysTs&latlng=' + childData.lat + ',' + childData.longi + '&sensor=false';
dat2.push(childData.incidencias);
       //  console.log(geocoding);
          $.getJSON(geocoding).done(function(location) {
            console.log(location.results[0].formatted_address);

dat1.push(location.results[0].formatted_address);
            console.log('array1:', dat1);
          var data = [
        {
          x:dat1,
          y: dat2,
          type: 'bar'
        }
      ];

      Plotly.newPlot('plotlyChart', data);
          //  document.write("<br />"+location.results[0].formatted_address)
            
         });
           
      
    // ...
  });
});


						   </script>



					    <!-- 
						    <script async defer
						    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC9bYfEezaRArZJELDisPt73WUz-oysTs&callback=initMap">
						    </script> 
						     -->
				          </div>
				          <!--Botones parte baja-->
				          <div class="col-md-6" style="text-align: left;">
			         	 	<a href="estadisticas.php" class="btn btn-info" style="margin-top: 10px;margin-bottom: 10px; font-size: 20px">Incidencias</a>
			     	  	  </div>
						  <div class="col-md-6" style="text-align: right;">
		         	 		<a href="logout.php" class="btn btn-danger" style="margin-top: 10px;margin-bottom: 10px; font-size: 20px">Cerrar Sesion</a>
		     	  		  </div>
					</div>
				</div>



				
		
	
</body>
</html>