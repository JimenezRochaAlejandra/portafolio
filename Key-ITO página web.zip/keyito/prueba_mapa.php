<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Waypoints in Directions</title>
    <style>
      #right-panel {
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
      }

      #right-panel select, #right-panel input {
        font-size: 15px;
      }

      #right-panel select {
        width: 100%;
      }

      #right-panel i {
        font-size: 12px;
      }
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #map {
        height: 100%;
        float: left;
        width: 70%;
        height: 100%;
      }
      #right-panel {
        margin: 20px;
        border-width: 2px;
        width: 20%;
        height: 400px;
        float: left;
        text-align: left;
        padding-top: 0;
      }
      #directions-panel {
        margin-top: 10px;
        background-color: #FFEE77;
        padding: 10px;
        overflow: scroll;
        height: 174px;
      }
    </style>
  </head>
  <body>
    <div id="map"></div>
    <div id="right-panel">
    <div>
    <b>Inicio:</b>
    <input type="text" id="start">
    <br>
    <select multiple id="waypoints" hidden>
    </select>
    <br>
    <b>Termina:</b>
    <input type="text" id="end">
    <br>
      <input type="submit" id="submit">
    </div>
      <h4 id="kilometros" class="letras">
       Distancia en kilometros: 
    </h4>
    <h4 id="mets" class="letras" >
      Distancia en mts: 
    </h4>
    
    <h4 id="tiempo" class="letras">
       Minutos: 
    </h4>
     <h4 id="tl" class="letras" >
       Total a pagar $: 
    </h4>
    </div>
    <script>
      function initMap() {
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 6,
          center: {lat: 41.85, lng: -87.65}
        });
        directionsDisplay.setMap(map);

        document.getElementById('submit').addEventListener('click', function() {
          calculateAndDisplayRoute(directionsService, directionsDisplay);
        });
      }

      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
                directionsService.route({
          origin: document.getElementById('start').value,
          destination: document.getElementById('end').value,
           optimizeWaypoints: true,
          travelMode: 'DRIVING'

        }, function(response, status) {
          if (status === 'OK') {

             // Aqui con el response podemos acceder a la distancia como texto 
                
                var km =response.routes[0].legs[0].distance.text;
                console.log(km);

                // Obtenemos la distancia como valor numerico en metros 
                var metross = parseFloat(response.routes[0].legs[0].distance.value);
                var comision =0.25; 
                var total = parseFloat(comision * metross);
                console.log("total a pagar = $ "+total);

            directionsDisplay.setDirections(response);
            // Obtener la duración para la primer ruta
    var route = response.routes[0];
    var duration = 0;

    // Iteramos todos los legs de la ruta
    route.legs.forEach(function (leg) {
      // Sumamos la duracion de cada uno
      // La duración esta en segundos.
      duration += leg.duration.value;

    });

    var  minutos =parseFloat(duration/60);
     console.log(minutos+ " minutos");
     document.getElementById('tiempo').innerHTML = "Minutos: " + minutos+ " minutos";
     document.getElementById('kilometros').innerHTML = "Distancia en kilometros: "+ km;
     document.getElementById('mets').innerHTML = "Distancia en mts: "+ metross+ " mts";
     document.getElementById('tl').innerHTML = "Total a pagar $: "+ total+ " pesos";

          } else {
            window.alert('Direccion no valida ' + status);
          }
        });
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?keyAIzaSyDC9bYfEezaRArZJELDisPt73WUz-oysTs&callback=initMap">
    </script>
  </body>
</html>