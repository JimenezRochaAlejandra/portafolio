<?php
	session_start();

	require_once ('vendor/autoload.php');
	require_once('app/auth/auth.php');

?>

<!DOCTYPE html>
<html>
<head>
	<?php if (Auth::isLogin()): ?>
				<title>DRuber, seguimiento de paquete</title>
	<?php else: ?>
	<?php Auth::getUserAuth();?>
				<title>¡ERROR!</title>
	<?php endif; ?>

	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-social.css">
	<script src="assets/js/jquery.js" charset="utf-8"></script>
	<meta charset='utf-8' />
    <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
	<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />

  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-app.js"></script>

  <!-- Add Firebase products that you want to use -->
  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-auth.js"></script>
  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-database.js"></script>
	<style type="text/css">
		body {
			background-image: url("assets/fonts/fondoweb.jpg");
			margin: 100px;
			width: 100px;
			<?php if (Auth::isLogin()): ?>
				margin-left: 50px;
				margin-top: 30px;
			<?php else: ?>
			<?php Auth::getUserAuth();?>
				margin-left: 450px;
				margin-top: 150px;
				text-align: center;
			<?php endif; ?>
		}
		#contenedorLogin{
		margin-left: 10px;
		margin-top: 10px;
        width: 1470px;
        height: auto;
        background-color: #E4ECED;
        //font-family: "Verdana",Verdana,Sans-serif;
        }
		#contenedorLogout{
        width: 450px;
        height: 280px;
        background-color: white;
        font-family: "Verdana",Verdana,Sans-serif;
        font-size: 30px;
      	}

     #right-panel {
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
        float: right;
        width: 40%;
        height: 100%;
      }

      #right-panel select, #right-panel input {
        font-size: 14px;
      }

      #right-panel select {
        width: 100%;
      }

      #right-panel i {
        font-size: 12px;
      }
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #map {
        height: 100%;
        float: left;
        width: 800px;
        height: 600px;
      }
	</style>
</head>
<body>
	<?php if (Auth::isLogin()): ?>
				<div class="container" id="contenedorLogin">
					<div class="form-row">
            <br>
            <div class="col-md-10" style="text-align: right;margin-bottom: 10px">
              <label style="font-size: 25px"><b><i>Revisa por Donde va tu Paquete</i></b></label>
            </div>
            
				          <!--Mapa de Google-->
				          <div class="col-md-12">
				          	<div id="map" class="col-md-6"></div>
						   
						    <script>

						    var firebaseConfig = {
         apiKey: "AIzaSyDuSB9xrZwotA4ISWb-IKQ60Y4HVKyyjm4",
         authDomain: "uber-1ce9b.firebaseapp.com",
         databaseURL: "https://uber-1ce9b.firebaseio.com",
         projectId: "uber-1ce9b",
         storageBucket: "",
         messagingSenderId: "1021375744315",
         appId: "1:1021375744315:web:24c137eb0bb217b14ccf1e"
         };

       // Initialize Firebase 
       firebase.initializeApp(firebaseConfig);
       var db = firebase.database();
       var ref = db.ref('coordenadas');
       var ref2 = db.ref('usuarios/1');
    

						      function initMap() {
                                       

                                
 //con esta función recorre todos los datos almacenados en FB ordenados por mi child(tipo)
					      	var map = new google.maps.Map(document.getElementById('map'), {
						          zoom: 4,
						          center: {lat: -24.345, lng: 134.46}  // Australia.
						        });

						        var directionsService = new google.maps.DirectionsService;
						        var directionsDisplay = new google.maps.DirectionsRenderer({
						          //draggable: true,
						          map: map,

						          
						        });

						        directionsDisplay.addListener('directions_changed', function() {
						          computeTotalDistance(directionsDisplay.getDirections());
						        });
						        //grafica los datos de firebas epara ver donde se encuentra el paquete

                                 ref.on("value", function(snapshot) {
                                  console.log(snapshot.val().origen1);

						        displayRoute(snapshot.val().origen1, snapshot.val().destino1, directionsService,
						            directionsDisplay);
                                    }, function (error) {
                               console.log("Error: " + error.code);
                                         });
          

                                 ref2.on("value", function(snapshot) {
                                   console.log(snapshot.val().longitud);
var marker = new google.maps.Marker({
    position:new google.maps.LatLng( snapshot.val().latitud_repartidor,snapshot.val().longitud_repartidor),
    title:"Conductor",
    map: map,
    icon:"assets/fonts/car1.png"

  });     
                                    }, function (error) {
                               console.log("Error: " + error.code);
                                         });
                               
						          

						      }

						      function displayRoute(origin, destination, service, display) {

						        service.route({
						          origin: origin,
						          destination: destination,
						          travelMode: 'DRIVING',
						          avoidTolls: true
						        }, function(response, status) {
						          if (status === 'OK') {
						            display.setDirections(response);

						            //console.log(origin_location);
						          } else {
						            alert('Could not display directions due to: ' + status);
						          }
						        });

                                   
						      }


						      var inicio = false;
						      var destino = false;
						      var costo = false;
						      function computeTotalDistance(result) {

						        var total = 0;
						        var myroute = result.routes[0];
						        for (var i = 0; i < myroute.legs.length; i++) {
						          total += myroute.legs[i].distance.value;
						        }
						        var tiempo = 0;
						        tiempo = result.routes[0].legs[0].duration.value;
						        tiempo = tiempo/60;
						        totalkm = total / 1000;
						        costo = totalkm*4.50;
						        document.getElementById('totalkm').innerHTML = totalkm + ' km';
						        document.getElementById('total').innerHTML = total + ' m';
						        document.getElementById('costo').innerHTML = costo.toFixed(2) + ' pesos';
						        document.getElementById('tiempo').innerHTML = tiempo + ' min';
                             
                             
						        inicio = result.routes[0].legs[0].start_address;
						        destino = result.routes[0].legs[0].end_address;
                                 
                                   writeUserData(1, inicio, destino,costo.toFixed(2),totalkm);


						        
						     // console.clear();
						        console.log(result.routes[0].legs[0].start_address);
						        console.log(result.routes[0].legs[0].end_address);
						         ;
						      }

						      
						      function writeUserData(userId, origen, destino,costo,distancia) {
                                  firebase.database().ref('coordenadas/' + userId).set({
                                        origen: origen,
                                        destino: destino,
                                         costo:costo,
                                          distanci:distancia,

                                         });
                                         }


						      //Mandar al post
						       	function llamadaalpost(){
						       	var data = {};
						        data.inicio = inicio;
						        data.destino = destino;
						        data.costo = costo;
						     //  writeUserData(1, inicio, destino);
						        var url = "probandopost.php";
						        $.ajax({
							        method: 'POST',
							        url: url,
							        data: data,   
							        //acá están todos los parámetros (valores a enviar) del POST
							        success: function(response){
							            // Se ejecuta al finalizar
							            //   mostrar si está OK en consola
							            //console.log(response);
							            window.location = "http://localhost/login_social/vista_prepago.php"; 
							        }
							    });
						       	}


						       	


						    </script>
						    
						    <script async defer
						    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC9bYfEezaRArZJELDisPt73WUz-oysTs&callback=initMap">
						    </script>
				          </div>
				          <!--Botones parte baja-->
				          <div class="col-md-6" style="text-align: left;">
			         	 	<a href="vista_destinatario.php" class="btn btn-info" style="margin-top: 10px;margin-bottom: 10px; font-size: 20px">Volver</a>
			     	  	  </div>
						  <div class="col-md-6" style="text-align: right;">
		         	 		<a href="logout.php" class="btn btn-danger" style="margin-top: 10px;margin-bottom: 10px; font-size: 20px">Cerrar Sesion</a>
		     	  		  </div>
					</div>
				</div>
		<?php else: ?>
	<?php Auth::getUserAuth();?>
				<div class="container" id="contenedorLogout">
					<div class="form-row">
						<div class="col-md-12" style="color: red;font-size: 50px; margin-top: 30px">
							¡E R R O R!
						</div>
						<div class="col-md-12" style="margin-top: 30px">
							No tienes acceso a esta pagina.
						</div>
						<div class="col-md-12" style="margin-top: 35px">
							<a style="font-size: 20px;" class="btn btn-primary" href="http://localhost/login_social/index.php">Pagina principal</a>
						</div>
					</div>
				</div>
		<?php endif; ?>
</body>
</html>