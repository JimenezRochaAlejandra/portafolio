<?php
session_start();

	require_once ('vendor/autoload.php');
	require_once('app/auth/auth.php');

	if (isset($_POST['inicio']) && !empty($_POST['inicio']) && isset($_POST['destino']) && !empty($_POST['destino']) && isset($_POST['costo']) && !empty($_POST['costo'])) {
    // Datos recibstartos
		print_r($_POST);
	$user = $_SESSION['user']['name'];
    $inicio = $_POST['inicio'];
    $destino =$_POST['destino'];
    $costo = $_POST['costo'];

    $enlace = mysqli_connect("localhost", "root", "", "sociallogin");
		 
		if (!$enlace) {
		    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
		    echo "error de depuración: " . mysqli_connect_errno() . PHP_EOL;
		    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
		    exit;
		}
		
				mysqli_query($enlace,"UPDATE envio SET direccion_remitente = '$inicio', direccion_destinatario = '$destino', costo = '$costo' where remitente = '$user'");
				mysqli_query($enlace,"UPDATE remitente SET direccion = '$inicio' where remitente = '$user'");

				mysqli_close($enlace);

    // Devolver una respuesta a JavaScript
    echo "Se grabó el inicio = $inicio, y el destino = $destino";

}
	
?>