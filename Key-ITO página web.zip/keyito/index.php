<?php
	session_start();

	require_once ('vendor/autoload.php');
	require_once('app/auth/auth.php');

?>

<!DOCTYPE html>
<html>
<head>
	
	<?php if (Auth::isLogin()): ?>
				<title>Paqueteria DRuber</title>
		<?php else: ?>
	<?php Auth::getUserAuth();?>
				<title>¡Inicia Sesion!</title>
		<?php endif; ?>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-social.css">
	<script src="assets/js/jquery.js" charset="utf-8"></script>
	<meta charset='utf-8' />
    <meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
    <script src='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.js'></script>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.css' rel='stylesheet' />
    <link rel="stylesheet" href="main.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<style type="text/css">


		body {
			background-image: url("assets/fonts/fondoweb.jpg");
			margin: 100px;
			width: 100px;
			<?php if (Auth::isLogin()): ?>
				margin-bottom: 20px;
				<?php else: ?>
			<?php Auth::getUserAuth();?>
						margin-left: 450px;
						margin-top: 150px;
						text-align: center;
				<?php endif; ?>
		}
		#contenedor{
        width: 500px;
        height: 380px;
        background-color: #E4ECED;
        font-family: "Verdana",Verdana,Sans-serif;
        font-size: 30px;
      	}
      	#contenedor2{
      	margin-top: -50px;
      	margin-left: 160px;
        width: 1000px;
        height: 100%;
        background-color: #E4ECED;
        font-family: "Verdana",Verdana,Sans-serif;
      }
	</style>
</head>

<body>
	<!-- The core Firebase JS SDK is always required and must be listed first -->
 <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-app.js"></script>

  <!-- Add Firebase products that you want to use -->
  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-auth.js"></script>
  <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-database.js"></script>
<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#config-web-app -->



<script>
  // Your web app's Firebase configuration
 var firebaseConfig = {
    apiKey: "AIzaSyCPs_4lN_dXX0fZr09M888HCs1QZvN82XU",
    authDomain: "keyito.firebaseapp.com",
    databaseURL: "https://keyito.firebaseio.com",
    projectId: "keyito",
    storageBucket: "keyito.appspot.com",
    messagingSenderId: "589526498841",
    appId: "1:589526498841:web:5c79f5d25770b77d5af488"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  var  database= firebase.database();
 
    createUser("die@hotmail.com", "123");

</script>

	<?php if (Auth::isLogin()): ?>
				<div class="container" id="contenedor2">
		<?php else: ?>
	<?php Auth::getUserAuth();?>
				<div class="container" id="contenedor">
		<?php endif; ?>
	
		
		<!--SEGUNDO CONTENEDOR, YA QUE SE HA CONSEGUIDO EL LOGIN-->
			<?php if (Auth::isLogin()):
				#Si el usuario esta logueado
			 ?>
				<div class="container-fluid rounded"  >
					<br><br>
		          	<div class="col-md-12" style="color: #00688B;font-size: 35px;text-align: center;">
		          	<b><b>Bienvenido a <i>DRuber</i></b> </b>
		            </div>
		            <div class="w-100"></div>
		          	<div class="col-md-12" style="font-style: bold;color: black;font-size: 30px;text-align: center;">
		          		<?php echo $_SESSION['user']['name'] ?> !
		          	</div>
		          	<div class="col-md-12" style="font-size: 20px;color: #00688B;text-align: center;margin-top: 50px">
		          	Para mandar un paquete sigua presione el boton "Iniciar Envio"
		          </div>
		          <div class="col-md-4">
		          	<img src="assets/fonts/paqueteenvio.png" width="300px" height="240px" style="margin-left: 300px">
		          </div>
		          <div class="col-md-7" style="font-size: 20px;color: black;text-align: left;margin-top: 10px">
		          	
		          
		          
		          </div>
		          <div class="w-100"></div>
		          <!--Boton que redirecciona a la pantalla de remitente-->
		          <div class="col-md-9" style="text-align: center;font-size: 20px;">
		          	<a class="btn btn-success" style="width: 300px;margin-left: 300px" href="http://localhost/login_social/vista_remitente.php">Iniciar Envio</a>
		          </div>
		          
		            <div class="w-100"></div>

		            <div class="col-md-9" style="text-align: center;font-size: 20px;">
		            	<br>
		          	<a class="btn btn-success" style="width: 300px;margin-left: 300px" href="http://localhost/login_social/vista_mapa_seguimiento.php">Verificar Envio</a>
		          </div>
		         <!-- 
		          <div class="col-md-9" style="text-align: center;font-size: 20px;">
		          	<a class="btn btn-success" style="width: 300px;margin-left: 300px" href="http://localhost/uber/vista_mapa_seguimiento.php">Ver estado de envios</a>
		          </div>
		         -->
		          <hr>
		          <br> <br> <br>
		          <!--Boton Cerrar Sesión-->
		          <div class="col-md-12" style="text-align: right;">
		          	<br>
		         	 <a href="logout.php" class="btn btn-danger" style="margin-top: 50px;margin-bottom: 10px; font-size: 20px">Cerrar Sesion</a>
		     	  </div>
		          <!--/div-->
		        </div>
		        

		    <?php else: ?>
			<?php
			#Si el usuario no esta logueado
				Auth::getUserAuth();
			?>
			<div class="form-row " id="contenedor" >
		<!--PAGINA PRINCIPAL-->
		<br>
		<div class="col-md-4" style="margin-left: 125px">
		          	<img src="assets/fonts/envioIcon.png" width="200px" height="140px">
		          </div>

			<div class="col-md-12" style="margin-top: 20px"></div>
			<div class="col-md-12" style="font-size: 24px;"><b>Paqueteria <i>DRuber</i></b></div>
			<br><br><br>
			<div class="col-md-12" style="font-size: 18px;">Inicie sesión para continuar con el Envio</div>
			<br>
			<div class="col-md-12" style="margin-top: 10px;">
				<br>
				<a href="?login=Facebook" class="btn btn-block btn-social btn-facebook"><span class="fa fa-facebook"></span>Iniciar sesion con Facebook</a>
				
			</div>
			<?php endif; ?>
		</div>
	</div>
<<script>
	
	function createUser(email, password) {
	console.log('Creando el usuario con email ' + email);

	firebase.auth().createUserWithEmailAndPassword(email, password)
	.then(function (user) {
		console.log('¡Creamos al usuario!');
	})
	.catch(function (error) {
		console.error(error)
	});
}

</script>
</body>

</html
