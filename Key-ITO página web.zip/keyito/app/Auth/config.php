<?php
  return

  array(
    "base_url" => "http://localhost/login_social/hydridauth.php",
    "providers" => array(
      "Twitter" => array(
        "enabled" => true,
        "keys" => array(
          "key" => "6QUKlG1AaMVZKVP2zhWkZqDQO",
          "secret" => "pohnXEB0rGleUgiD3VlzjM71wVHTPLpNFHMlukBYy25JCvOJll"
        ),
        "includeEmail" => true
      ),
      "Facebook" => array(
        "enabled" => true,
        "keys" => array(
          "id" => "304732853533038",
          "secret" => "3e2385809688471f0f0a7ad5735c0a67"
        ),
        "scope" => "email"
      ),
      "Google" => array(
        "enabled" => true,
        "keys" => array(
          "id" => "431241787265-r8109lv6fsu2uk470vh53tlsbuthc8ph.apps.googleusercontent.com",
          "secret" => "qAiVPb8SCy0ki8frhIPr851E"
        )
      ),
      "LinkedIn" => array(
        "enabled" => true,
        "keys" => array(
          "id" => "787l8r9bbx8yso",
          "secret" => "1G3HzdiWY4inZkB0"
      )
    )
    )
  )

 ?>
