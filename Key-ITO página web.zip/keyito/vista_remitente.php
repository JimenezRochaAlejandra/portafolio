<?php
	session_start();

	require_once ('vendor/autoload.php');
	require_once('app/auth/auth.php');

?>

<!DOCTYPE html>
<html>
<head>
	<?php if (Auth::isLogin()): ?>
				<title>Bienvenido a DRuber</title>
	<?php else: ?>
	<?php Auth::getUserAuth();?>
				<title>¡ERROR!</title>
	<?php endif; ?>

	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-social.css">
	<script src="assets/js/jquery.js" charset="utf-8"></script>
	<meta charset='utf-8' />
    <meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
    <script src='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.js'></script>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v0.53.1/mapbox-gl.css' rel='stylesheet' />
    <link rel="stylesheet" href="main.css">
    <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
	<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

	<style type="text/css">
		body {
			background-image: url("assets/fonts/fondoweb.jpg");
			margin: 100px;
			width: 100px;
			<?php if (Auth::isLogin()): ?>
				margin-left: 200px;
				margin-top: 50px;
			<?php else: ?>
			<?php Auth::getUserAuth();?>
				margin-left: 450px;
				margin-top: 150px;
				text-align: center;
			<?php endif; ?>
		}
		#contenedorLogin{
        width: 1000px;
        height: 100%;
        background-color: #E4ECED;
        font-family: "Verdana",Verdana,Sans-serif;
        }
		#contenedorLogout{
        width: 450px;
        height: 280px;
        background-color: white;
        font-family: "Verdana",Verdana,Sans-serif;
        font-size: 30px;
      	}
	</style>
</head>
<body>
	<?php if (Auth::isLogin()): ?>
				<div class="container" id="contenedorLogin">
					<hr>
					<div class="form-row">
						<div class="col-md-12">
							<label style="font-size: 20px">Confirma tus datos:</label>
						</div>
						<br><br><br>
						<div class="col-md-1"></div>
						<div class="col-md-8" style="font-size: 30px;color: #00688B">
							<div class="well" style="width: 600px">
						    <ul class="nav nav-tabs">
						      <label style="text-align: center;font-size: 25px">
						      	Datos Remitente
						  	  </label>
						  	  <br>
						    </ul>
						    <div id="myTabContent" class="tab-content">
						      <div class="tab-pane active in" id="home">
						        <form id="tab" method="POST" action="http://localhost/login_social/controllers/envio.php">
						        	<br>
						            <label><i>Nombre</i></label>
						            <input name="nombre" type="text" value="<?php echo $_SESSION['user']['name'] ?>" class="input-xlarge" readonly>
						            <label><i>Correo electronico</i></label >
						            <input name="correo" type="text" value="<?php echo $_SESSION['user']['email'] ?>" class="input-xlarge" readonly>
						            <br><br><br>
						          	<div style="text-align: center; margin-top: 10px;margin-bottom: 10px;">
						        	    <input class="btn btn-success" type="submit" name="Confirmar" id="Guardar" value="Confirmar">
						        	</div>
						        </form>
						      </div>
						  </div>
						</div>
					</div>
						
						<div class="col-md-6" style="text-align: left;">
							<br><br>
		         	 <a href="index.php" class="btn btn-info" style="margin-top: 10px;margin-bottom: 10px; font-size: 20px">Volver</a>
		     	  </div>
						<div class="col-md-6" style="text-align: right;">
							<br><br>
		         	 <a href="logout.php" class="btn btn-danger" style="margin-top: 10px;margin-bottom: 10px; font-size: 20px">Cerrar Sesion</a>
		     	  </div>
					</div>
				</div>
		<?php else: ?>
	<?php Auth::getUserAuth();?>
				<div class="container" id="contenedorLogout">
					<div class="form-row">
						<div class="col-md-12" style="color: red;font-size: 50px; margin-top: 30px">
							¡E R R O R!
						</div>
						<div class="col-md-12" style="margin-top: 30px">
							No tienes acceso a esta pagina.
						</div>
						<div class="col-md-12" style="margin-top: 35px">
							<a style="font-size: 20px;" class="btn btn-primary" href="http://localhost/login_social/index.php">Pagina principal</a>
						</div>
					</div>
				</div>
		<?php endif; ?>
</body>
</html>