
<?php
require_once('vendor/autoload.php');

$stripe = [
  "secret_key"      => "sk_test_fGh7quBQlREOuACFpqBQ9b5n00TyBIHDQ5",
  "publishable_key" => "pk_test_EYCyxG3XvqKJcWDEIUTR6Xw900f0tDdDJx",
];

\Stripe\Stripe::setApiKey($stripe['secret_key']);
?>
