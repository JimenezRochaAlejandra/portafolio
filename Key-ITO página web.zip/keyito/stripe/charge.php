<?php

    session_start();

  require_once ('../vendor/autoload.php');
  require_once('../app/auth/auth.php');
  require_once('./config.php');

  $token  = $_POST['stripeToken'];
  $email  = $_POST['stripeEmail'];

  $customer = \Stripe\Customer::create([
      'email' => $email,
      'source'  => $token,
  ]);

  $charge = \Stripe\Charge::create([
      'customer' => $customer->id,
      'amount'   => 10099,
      'currency' => 'usd',
  ]);

  #echo '<h1>Su pago se ha realizado correctamente</h1>';
?>

<!DOCTYPE html>
<html>
<head>
  <title>Paqueteria "PaquetitosEnviaditos"</title>
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-social.css">
  <script src="assets/js/jquery.js" charset="utf-8"></script>
  <meta charset='utf-8' />
    <meta name='viewport' content='initial-scale=1,maximum-scale=1,user-scalable=no' />
    <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

  <style type="text/css">
    body {
      background-image: url("../assets/fonts/fondo.jpg");
      margin: 100px;
      width: 100px;
        margin-left: 450px;
        margin-top: 150px;
        text-align: center;
    }
    #contenedorLogout{
        width: 450px;
        height: 280px;
        background-color: white;
        font-family: "Verdana",Verdana,Sans-serif;
        font-size: 30px;
        }
  </style>
</head>
<body>
        <div class="container" id="contenedorLogout">
          <hr>
          <div class="form-row">
            <div class="col-md-12">
              <h3>Su pago se realizo correctamente.</h3>
            </div>
            <div class="col-md-2" style="text-align: center;">
               <a href="http://localhost/login_social/logout.php" class="btn btn-danger" style="margin-top: 10px;margin-bottom: 10px; font-size: 20px">Cerrar Sesion</a>
            </div>
          </div>
        </div>
</body>
</html>