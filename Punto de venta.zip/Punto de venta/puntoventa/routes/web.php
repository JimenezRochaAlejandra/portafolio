<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','Auth\LoginController@showLoginForm');

Route::post('/login','Auth\LoginController@login')->name('login');

Route::post('/logout','Auth\LoginController@logout')->name('logout');


Route::group(['prefix' => 'admin','middleware'=>['auth','admin']], function() {
	Route::get('dashboard','DashboardController@index')->name('dashboard');
	
	Route::group(['prefix' => 'dashboard'], function() {

		  
				
				Route::resource('products','ProductController');

				Route::resource('users','UserController');

				Route::resource('employees','EmployeeController');

				Route::resource('sales', 'SaleController', ['except' => [
   				 'create', 'store'
				]]);

				Route::get('reports','ReportController@index')->name('reports.index');
				Route::group(['prefix'=>'reports'],function(){
					
					Route::get('day','ReportController@rdia')->name('reports.dia');
					
					Route::get('month','ReportController@rmes')->name('reports.mes');

					Route::get('products','ReportController@rproductos')->name('reports.products');

					Route::get('employees','ReportController@rempleados')->name('reports.employees');

					Route::get('details/day','ReportController@rdetalledias')->name('reports.detailsdias');

					Route::get('details/month','ReportController@rdetallemes')->name('reports.detailsmes');

					Route::get('details/products','ReportController@rdetalleproductos')->name('reports.detailsproducts');

					Route::get('details/employees','ReportController@rdetalleempleados')->name('reports.detailsemployees');


				});
				

			
});
});

Route::group(['prefix' => 'vendedor'], function() {
	Route::get('dashboard','DashboardController@index2')->name('dashboard2');
	
	Route::group(['prefix' => 'dashboard'], function() {

		  		Route::resource('sales', 'SaleController', ['only' => [
   				 'create', 'store'
				]]);
				
			
				
});
});