<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
  //protected $table = 'products';
  //protected $fillable = ['name_product', 'mark'];
  ///protected $guarded = ['id_product'];


  public function scopeSearch($query,$nombre)
   {
   	return $query->where('name_product','LIKE',"%name_product%");
   } 
}
