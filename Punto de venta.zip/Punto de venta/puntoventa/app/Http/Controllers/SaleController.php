<?php

namespace App\Http\Controllers;
use App\Product;
use App\Sale;
use App\Sale_Product;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade as PDF;

class SaleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)

    {
        $ventas=Sale:: select('sales.id','users.name','sales.created_at')
        ->join('users', 'users.id', '=', 'sales.user_id')
        ->where('sales.flag', '1')
        ->where('sales.created_at','LIKE','%'.$request->busc.'%')
        ->get();

       
        return view('admin.ventas.mostrar_ventas') 
        ->with('ventas',$ventas);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $productos= Product:: select( 'id','name_product','mark','sale_price','purchase_price')->where('flag','=','1')->get();
      
        //dd($productos);
        return view('vendedor.ventas.venta')
        ->with('productos',$productos);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $json_sale_product = json_decode($request->datos);

        if(sizeof($json_sale_product)==0){
             return redirect()->route('sales.create');
        }
        
         $sale= new Sale();

        $sale->user_id=Auth()->user()->id;
        $sale->flag='1';

    
        $sale->save();
for ($i=0; $i <sizeof($json_sale_product) ; $i++) { 
        
        $sale_product=new Sale_Product();

        $sale_product->sales_id=$sale->id;
        $sale_product->products_id=intval($json_sale_product[$i]->products_id);
        $sale_product->quantyti_product=intval($json_sale_product[$i]->quantyti_product);

        $producto= Product::find($sale_product->products_id);
        $producto->stock=($producto->stock-$sale_product->quantyti_product);

        if ($producto->stock<0) {
        $sale = Sale::find($sale->id);
        $sale->delete();
        return back();
        }
       
        $sale_product->save();
    
}
        $total_price=$request->total_price;
        $data = $json_sale_product;
        $date=  $sale->created_at;
        $view=  \View::make('recibo', compact('data','total_price','date'))->render();
           $pdf = \App::make('dompdf.wrapper');
            //$pdf->loadHTML('vistaPDF');

            $pdf = PDF::loadHTML($view);
            
            return $pdf->stream('recibo');
            
       
       // return redirect()->route('sales.create')->with('ventaA',$json_sale_product) ;
            
        
        
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //$productos=Product::find($id);

        

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $iden=intval($id);
        $productos= Product:: select( 'id','name_product','mark','sale_price','purchase_price')->where('flag','=','1')->get();

        $venta_producto=Sale_Product:: select('sale__products.sales_id','products.id','products.name_product','products.mark','sale__products.quantyti_product','products.sale_price')->join('products','products.id','=','sale__products.products_id')
        ->where('sale__products.sales_id', $iden)
        ->get();
        //dd($venta_producto);

       return view('admin.ventas.act_ventas')

       -> with('ventas',$venta_producto)
       ->with('productos',$productos)
       ->with('iden',$iden);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $json_sale_product = json_decode($request->datos);

        if(sizeof($json_sale_product)==0){
             return redirect()->route('sales.create');
        }
    $venta_producto=Sale_Product::where('sales_id', '=',$id)->delete();
     
      
 

    for ($i=0; $i <sizeof($json_sale_product) ; $i++) { 
        
        $sale_product=new Sale_Product();

        $sale_product->sales_id=$id;
        $sale_product->products_id=intval($json_sale_product[$i]->products_id);
        $sale_product->quantyti_product=intval($json_sale_product[$i]->quantyti_product);

        $producto= Product::find($sale_product->products_id);
        $producto->stock=($producto->stock-$sale_product->quantyti_product);

        if ($producto->stock<0) {
        //$sale = Sale::find($id);
        //$sale->delete();
        return back();
        }
       
        $sale_product->save();
        $producto->save();

    
}
        

        
        
        return redirect()->route('sales.index')->with('notice','Venta Editada exitosamente');; 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $venta= Sale::find($id);
        $venta->flag='0';

        $venta->save(); 

        return redirect()->route('sales.index');
    }

     public function pdf()
    {        
        /**
         * toma en cuenta que para ver los mismos 
         * datos debemos hacer la misma consulta
        **/
        $pdf = PDF::loadView('vistaPDF');
        return $pdf->download('tikect.pdf');

        
    }
}
