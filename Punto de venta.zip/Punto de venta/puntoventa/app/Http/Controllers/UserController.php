<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
use Laracasts\Flash\Flash;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $usuarios= User:: select('id','name','type')->where('flag','=','1')->where('name','LIKE','%'.$request->busc.'%')->get();
        return view('admin.usuarios.mostrar_usuario')->with('usuarios',$usuarios);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.usuarios.nuevo_usuario');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

       $usuario= new User();

        $usuario->name= $request->name;
//'password'=>$password ?: $password = bcrypt('secret')
        $usuario->password= bcrypt($request->password); 
        $usuario->type=$request->tipo;
        
        $usuario->flag='1';
        
        if ( $request->password== $request->confpas) {
        
            $usuario->save();
            
            return redirect()->route('users.index')->with('notice','Usuario Guardado exitosamente');
        }
       return back()
       ->withErrors(['name'=> 'las contraseña no coinciden . Porfavor verifica los campos'])
       ->withInput(request([$this->username()]));

        //return redirect()->route('users.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $usuario=User::find($id);
        return view('admin.usuarios.act_usuario')->with('usuario',$usuario);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $usuario= User::find($id);

        $usuario->name= $request->name;
//'password'=>$password ?: $password = bcrypt('secret')
        $usuario->password= bcrypt($request->password); 
        $usuario->type=$request->tipo;
        
        $usuario->flag='1';
        
        if ( $request->password== $request->confpas) {
        
            $usuario->save();
            return redirect()->route('users.index')->with('notice','Usuario Actualizado exitosamente');
        }
       return back()
       ->withErrors(['name'=> 'las contraseña no coinciden . Porfavor verifica los campos'])
       ->withInput(request([$this->username()]));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $usuario= User::find($id);
        $usuario->flag='0';

        $usuario->save(); 

        return redirect()->route('users.index');
    }
    public function username()
    {
        return 'name';
    }
}
