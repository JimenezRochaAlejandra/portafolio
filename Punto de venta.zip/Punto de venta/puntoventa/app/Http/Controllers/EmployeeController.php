<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
         $empleados= Employee:: select('id','name','last_name','salary')->where('flag','=','1')->where('name','LIKE','%'.$request->bus.'%')->get();
        return view('admin.empleados.mostrar_empleados')->with('empleados',$empleados);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.empleados.new_empleado');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $empleado=new Employee();

        $empleado->name= $request->name;
        $empleado->last_name= $request->last_name;
        $empleado->salary=  floatval($request->salary);
        $empleado->flag='1';

        $empleado->save();

        return redirect()->route('employees.index')->with('notice','Empleado Guardado exitosamente');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
         $empleado=Employee::find($id);
        return view('admin.empleados.act_empleado')->with('empleado',$empleado);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $empleado=Employee::find($id);

         $empleado->name= $request->name;
        $empleado->last_name= $request->last_name;
        $empleado->salary=  floatval($request->salary);
        $empleado->flag='1';

        $empleado->save();

        return redirect()->route('employees.index')->with('notice','Usuario Editado exitosamente');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $empleado= Employee::find($id);
        $empleado->flag='0';

        $empleado->save(); 

        return redirect()->route('employees.index');
    }
}
