<?php

namespace App\Http\Controllers;
use App\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
	public function index(Request $request)

	{

		/*$productos= Product:: select('id','name_product','mark','description','provider','stock','sale_price','purchase_price')->where('flag','=','1')->get();
		*/
		$productos= Product::where('flag','=','1')->where('name_product','LIKE','%'.$request->name_product.'%')->get();

		//dd($request->name_product);


		return view('admin.productos.pruebaHe')->with('productos',$productos);
		//return view('productos.pruebaHe');
	}

	public function create()
	{
		
		
		return view('admin.productos.agregar_productos');

	}
	public function store(Request $request)
	{
		$producto= new Product();

		$producto->name_product= $request->name_product;
		$producto->mark= $request->mark;
		$producto->description=$request->description;
		$producto->provider=$request->provider;
		$producto->stock= intval($request->stock);
		$producto->sale_price= floatval($request->sale_price);
		$producto->purchase_price= floatval($request->purchase_price);
		$producto->flag='1';

		
		$producto->save();

		return redirect()->route('products.index')->with('notice','Producto Guardado exitosamente');;
	}
	public function update(Request $request,$id)
	{
		$producto= Product::find($id);

		$producto->name_product= $request->name_product;
		$producto->mark= $request->mark;
		$producto->description=$request->description;
		$producto->provider=$request->provider;
		$producto->stock= intval($request->stock);
		$producto->sale_price= floatval($request->sale_price);
		$producto->purchase_price= floatval($request->purchase_price);


		$producto->save(); 
		return redirect()->route('products.index')->with('notice','Producto Editado  exitosamente');
	}
	public function edit($id)
	{	
		$producto= Product::find($id);

		return view('admin.productos.act_producto')->with('producto',$producto);
	}
	
	public function destroy($id)
	{
		$producto= Product::find($id);
		$producto->flag='0';

		$producto->save(); 

		return redirect()->route('products.index');
	}
}
