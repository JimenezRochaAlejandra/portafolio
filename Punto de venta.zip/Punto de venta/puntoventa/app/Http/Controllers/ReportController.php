<?php

namespace App\Http\Controllers;
use App\Product;
use App\Employee;
use App\Sale;
use App\Sale_Product;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        return view('admin.reportes.principal');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function rdia(Request $request)
    {
         $venta_producto=Sale:: select('sales.id','users.name','sales.created_at')
        ->join('users', 'users.id', '=', 'sales.user_id')
        ->where('sales.flag', '1')
        ->where('sales.created_at','LIKE','%'.$request->fecha.'%')
        ->orderBy('sales.id')
        ->get();

        //dd($venta_producto);
        return view('admin.reportes.reportes_dia')->with('venta_producto',$venta_producto);
    }

    public function rmes(Request $request)
    {
        $venta_producto=Sale:: select('sales.id','users.name','sales.created_at')
        ->join('users', 'users.id', '=', 'sales.user_id')
        ->where('sales.flag', '1')
        ->whereBetween('sales.created_at', array($request->fecha1,$request->fecha2))
        ->orderBy('sales.id')
        ->get();

        return view('admin.reportes.reportes_mes')->with('venta_producto',$venta_producto);
    }

 public function rproductos(Request $request)
    {
        $productos= Product::where('flag','=','1')->where('name_product','LIKE','%'.$request->name_product.'%')->get();

        return view('admin.reportes.reportes_productos')->with('productos',$productos);
    }


    public function rempleados(Request $request)
    {
         $empleados= Employee:: select('id','name','last_name','salary')->where('flag','=','1')->where('name','LIKE','%'.$request->bus.'%')->get();
        return view('admin.reportes.reportes_empleados')->with('empleados',$empleados);
    }

    public function rdetalledias(Request $request)
    {
        $json_sale_product = json_decode($request->datos);
        $arr;
        

        
       
        for ($i=0; $i <sizeof($json_sale_product) ; $i++)
        { 
            $venta_producto=Sale_Product:: select('sale__products.sales_id','products.id','products.name_product','products.mark','sale__products.quantyti_product','products.sale_price','products.description')
        ->join('products','products.id','=','sale__products.products_id')
        ->where('sale__products.sales_id', intval($json_sale_product[$i]->sale_id))
        ->orderBy('sale__products.sales_id')
        ->get();

        $arr[]=$venta_producto;

        }


        $data = $arr;
        $view=  \View::make('admin.reportes.pdf.reporte_ventas', compact('data'))->render();
           $pdf = \App::make('dompdf.wrapper');
            //$pdf->loadHTML('vistaPDF');

            $pdf = PDF::loadHTML($view);
            
            return $pdf->stream('admin.reportes.pdf.reporte_ventas');

       

         
    }
    public function rdetallemes(Request $request)
    {
        $json_sale_product = json_decode($request->datos);
        $arr;
         
       
        for ($i=0; $i <sizeof($json_sale_product) ; $i++)
        { 
            $venta_producto=Sale_Product:: select('sale__products.sales_id','products.id','products.name_product','products.mark','sale__products.quantyti_product','products.sale_price','products.description')
        ->join('products','products.id','=','sale__products.products_id')
        ->where('sale__products.sales_id', intval($json_sale_product[$i]->sale_id))
        ->orderBy('sale__products.sales_id')
        ->get();

        $arr[]=$venta_producto;

        }


        $data = $arr;
        $view=  \View::make('admin.reportes.pdf.reporte_ventas_mes', compact('data'))->render();
           $pdf = \App::make('dompdf.wrapper');
            //$pdf->loadHTML('vistaPDF');

            $pdf = PDF::loadHTML($view);
            
            return $pdf->stream('admin.reportes.pdf.reporte_ventas_mes');

       

         
    }

     public function rdetalleproductos()
    {
        
        $productos= Product::where('flag','=','1')
        ->get();
        $data = $productos;
        $view=  \View::make('admin.reportes.pdf.reporte_ventas_productos', compact('data'))->render();
           $pdf = \App::make('dompdf.wrapper');
            //$pdf->loadHTML('vistaPDF');
         // PDF::loadHTML($html)->setWarnings(false)->save('myfile.pdf') 
            $pdf = PDF::loadHTML($view)->setPaper('a4', 'landscape');
          
            return $pdf->stream('admin.reportes.pdf.reporte_ventas_productos');

       

         
    }

      public function rdetalleempleados()
    {
        
        $empleados= Employee::where('flag','=','1')
        ->get();
        $data = $empleados;
        $view=  \View::make('admin.reportes.pdf.reporte_ventas_empleados', compact('data'))->render();
           $pdf = \App::make('dompdf.wrapper');
            //$pdf->loadHTML('vistaPDF');
         // PDF::loadHTML($html)->setWarnings(false)->save('myfile.pdf') 
            $pdf = PDF::loadHTML($view);
          
            return $pdf->stream('admin.reportes.pdf.reporte_ventas_empleados');

       

         
    }
   
}
