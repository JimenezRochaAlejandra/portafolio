<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	static $password;
        //
        //DB:: table('users')-> truncate();
		DB:: table('users')-> insert([
		'name'=>'edwin1',
		'password'=>$password ?: $password = bcrypt('secret'),
		'type'=>'administrador',
		'flag'=>'1',
		]);
		
		
		DB:: table('users')-> insert([
		'name'=>'gibran1',
		'password'=>$password ?: $password = bcrypt('secret'),
		'type'=>'administrador',
		'flag'=>'1',
		]);
		
		
		DB:: table('users')-> insert([
		'name'=>'brenda1',
		'password'=>$password ?: $password = bcrypt('secret'),
		'type'=>'administrador',
		'flag'=>'1',
		]);
		
		
		DB:: table('users')-> insert([
		'name'=>'paola',
		'password'=>$password ?: $password = bcrypt('secret'),
		'type'=>'administrador',
		'flag'=>'1',
		]);

		DB:: table('users')-> insert([
		'name'=>'Juan',
		'password'=>$password ?: $password = bcrypt('secret'),
		'type'=>'administrador',
		'flag'=>'1',
		]);

		DB:: table('users')-> insert([
		'name'=>'Jose',
		'password'=>$password ?: $password = bcrypt('secret'),
		'type'=>'vendedor',
		'flag'=>'1',
		]);

    }
}
