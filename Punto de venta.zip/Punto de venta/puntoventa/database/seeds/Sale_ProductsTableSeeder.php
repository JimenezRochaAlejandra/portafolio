<?php

use Illuminate\Database\Seeder;

class Sale_ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB:: table('sale__products')-> insert([
		'sales_id'=>2,
		'products_id'=>1,
		'quantyti_product'=>2,
		]);

        DB:: table('sale__products')-> insert([
		'sales_id'=>2,
		'products_id'=>2,
		'quantyti_product'=>1,
		]);

		DB:: table('sale__products')-> insert([
		'sales_id'=>2,
		'products_id'=>3,
		'quantyti_product'=>1,
		]);

		DB:: table('sale__products')-> insert([
		'sales_id'=>3,
		'products_id'=>4,
		'quantyti_product'=>3,
		]);
    }
}
