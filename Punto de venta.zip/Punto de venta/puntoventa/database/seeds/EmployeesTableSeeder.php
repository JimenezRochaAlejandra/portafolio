<?php

use Illuminate\Database\Seeder;

class EmployeesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       // DB:: table('employees')-> truncate();
		DB:: table('employees')-> insert([
		'name'=>'Jose Federico',
		'last_name'=>'Perez Lopez',
		'salary'=>6500.50,
		'flag'=>'1',
		]);


		DB:: table('employees')-> insert([
		'name'=>'Marcos',
		'last_name'=>'Lopez Martinez',
		'salary'=>4850.50,
		'flag'=>'1',
		]);

		DB:: table('employees')-> insert([
		'name'=>'Jorge',
		'last_name'=>'Ramirez Antonio',
		'salary'=>3850.50,
		'flag'=>'1',
		]);

		DB:: table('employees')-> insert([
		'name'=>'Pablo',
		'last_name'=>'Luna Martinez',
		'salary'=>5500.70,
		'flag'=>'1',
		]);
    }
}
