<?php

use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //DB:: table('products')-> truncate();

		DB:: table('products')-> insert([
		'name_product'=>'refresco',
		'mark'=>'Coca-Cola Company',
		'description'=>'600 ml',
		'provider'=>'Coca-Cola Company',
		'stock'=>20,
		'sale_price'=>12.5,
		'purchase_price'=>10.6,
		'flag'=>'1',
		]);

		DB:: table('products')-> insert([
		'name_product'=>'Papel Higienico',
		'mark'=>'Suavel',
		'description'=>'paq 4 rollos',
		'provider'=>'fabrica Juan',
		'stock'=>10,
		'sale_price'=>10.5,
		'purchase_price'=>7.4,
		'flag'=>'1',
		]);

		DB:: table('products')-> insert([
		'name_product'=>'Pan integral',
		'mark'=>'Bimbo',
		'description'=>'grande',
		'provider'=>'Bimbo company',
		'stock'=>20,
		'sale_price'=>15.7,
		'purchase_price'=>11.2,
		'flag'=>'1',
		]);

		DB:: table('products')-> insert([
		'name_product'=>'Mayonesa',
		'mark'=>'Mccornick',
		'description'=>'chica',
		'provider'=>'fabricas el patito',
		'stock'=>15,
		'sale_price'=>7,
		'purchase_price'=>4.5,
		'flag'=>'1',
		]);
    }
}
