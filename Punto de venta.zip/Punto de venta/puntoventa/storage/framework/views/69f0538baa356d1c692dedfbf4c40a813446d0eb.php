<!DOCTYPE html>
<html>
<title>producto</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="estilo.css">
<body>

<div class="w3-container w3-blue">
  <h2>DATOS PRODUCTO</h2>
</div>

<form class="w3-container"  >
  <p>
  <label>Nombre</label>
  <input class="w3-input" type="text" name="name_product" required></p>
  <p>
  <label>Marca</label>
  <input class="w3-input" type="text" name="mark" required></p>
  <button class="prueba">
    Agregar
  </button>
</form>

</body>
</html> 
