<?php $__env->startSection('content'); ?>

    <h1 style="color: BLACK;">BIENVENIDO <?php echo e(Auth()->user()->name); ?></h1>

    <h3 style="color: BLACK;font-size: 300%;font-weight: bold; ">TIENDA DE ABARROTES "LA SOLEDAD"</h3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>