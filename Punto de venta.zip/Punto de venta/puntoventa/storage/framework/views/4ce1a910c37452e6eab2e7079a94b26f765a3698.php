<!DOCTYPE html>
<html lang="en">
<link href="<?php echo e(URL::asset('css/css_reporte_ventas.css')); ?>" rel="stylesheet">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body >
<p>REPORTE DE VENTAS POR DÍA</p>
<div>R.F.C TCH850701-RM1</div>
<div>Calzada Francisco I. Madero 1332</div>
<div>Col. Exmarquezado C.P. 68030</div>
<div>08/12/17 20:13</div>
<div>Teléfono: 9515327829 </div>
<br>
<table id="racetimes">
<tr id="firstrow">
          <th>ID</th>
          <th>NOMBRE</th>
          <th>MARCA</th>
          <th>DESCRIPCION</th>
          <th>PROVEEDOR</th>
          <th>EXISTENCIAS</th>
          <th>PRECIO DE VENTA</th>
          <th>PRECIO DE COMPRA</th>
</tr>
<?php $acum=0;
 $acumto=0;
 $acump=0;
 $acumpr=0;
 $acumtoo=0;
  ?> 
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name_product); ?></td>
                <td><?php echo e($item->mark); ?></td>
                <td><?php echo e($item->description); ?></td>
                <td><?php echo e($item->provider); ?></td>
                <td><?php echo e($item->stock); ?></td>
                <td>$ <?php echo e($item->sale_price); ?></td>
                <td>$ <?php echo e($item->purchase_price); ?></td>
               <?php
                $acum=$acum+ $item->sale_price ;
                $acump=$acump+ $item->purchase_price;
                $acumpr=$acumpr+$item->stock;
                $acumto=$acumto+($item->stock * $item->sale_price);
                $acumtoo=$acumtoo+($item->stock * $item->purchase_price);
               ?>
             </tr> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td>TOTAL$</td>
  <td><?php echo e($acumpr); ?></td>
  <td> <?php echo e($acum); ?></td>
  <td> <?php echo e($acump); ?></td>
</tr>
</table>

<div>
En base a la tabla obtenida se ha determinado que el total  de productos en la tienda es de <?php echo e($acumpr); ?>. Se espera una ganancia total de $<?php echo e($acumto); ?>. La inversion que se ha hecho es de $ <?php echo e($acumtoo); ?>, por lo que se espera que la ganancia neta sea de  $<?php echo e($acumto-$acumtoo); ?>  
</div>
</body>
<script src="https://code.jquery.com/jquery-3.1.0.js"></script>
</html>