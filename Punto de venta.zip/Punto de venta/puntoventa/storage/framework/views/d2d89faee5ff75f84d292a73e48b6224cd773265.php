<!DOCTYPE html>
<html lang="en">
<head>
  <title>Menu Productos</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>MENU PRODUCTOS</h2>
  <ul class="nav nav-tabs">
    
    <li><a data-toggle="tab" href="#menu1">Agregar Producto</a></li>
    <li><a data-toggle="tab" href="#menu2">Mostrar Productos</a></li>
    <li><a data-toggle="tab" href="#menu3">Actualizar Producto</a></li>
    <li><a data-toggle="tab" href="#menu4">Eliminar Producto</a></li>
  </ul>

  <div class="tab-content">
    
    <div id="menu1" class="tab-pane fade" >
            <div class="w3-container w3-black">
            <h2>DATOS PRODUCTO</h2>
            </div>
            <form class="w3-container" method='POST' action="<?php echo e(route('products.create')); ?>">
              
            <?php echo e(csrf_field()); ?>

            <p>
            <label>Nombre</label>
            <input class="w3-input" type="text" name="name_product" required></p>
            <p>
            <label>Marca</label>
            <input class="w3-input" type="text"  name="mark" required></p>
            <button class="prueba">AGREGAR</button>
            </form>
    </div>
    <div id="menu2" class="tab-pane fade" >
      <table class="table table-striped">
        <thead>
          <th>ID</th>
          <th>NOMBRE</th>
          <th>MARCA</th>
          <th>ACCIONES</th>
        </thead>
        <tbody>
          <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id_product); ?></td>
                <td><?php echo e($item->name_product); ?></td>
                <td><?php echo e($item->mark); ?></td>
                <td> <button class="btn btn-danger">ELIMINAR </button>
                     <button class="btn btn-info">ACTUALIZAR</button></td>


             </tr> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
      </table>
    </div>
    <div id="menu3" class="tab-pane fade">
      <div class="w3-container w3-yellow">
            <h2> ACTUALIZAR DATOS PRODUCTO</h2>
            </div>
            <form class="w3-container">
            <p>
            <label>Nombre</label>
            <input class="w3-input" type="text"></p>
            <p>
            <label>Marca</label>
            <input class="w3-input" type="text"></p>
            <button class="prueba">ACEPTAR</button>
            </form>
    </div>

    
    <div id="menu4" class="tab-pane fade">
          <div class="alert alert-danger">
          <strong>ALERTA!</strong> Seguro que deseas eliminar el registro?.
          <button class="prueba2">SI</button>
          <button class="prueba3">NO</button>
          </div>


    </div>
  </div>
</div>

</body>

<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
.prueba{
  color: #fff!important;
    background-color:   #FF4500!important;
    font-size: 18px!important;
        border: none;
    display: inline-block;
    outline: 0;
    padding: 8px 16px;
    vertical-align: middle;
    overflow: hidden;
    text-decoration: none;
    color: inherit;
    background-color: inherit;
    text-align: center;
    cursor: pointer;
    white-space: nowrap;
}

.prueba2{
  color: #fff!important;
    background-color:   #A52A2A!important;
    font-size: 18px!important;
        border: none;
    display: inline-block;
    outline: 0;
    padding: 8px 16px;
    vertical-align: middle;
    overflow: hidden;
    text-decoration: none;
    color: inherit;
    background-color: inherit;
    text-align: center;
    cursor: pointer;
    white-space: nowrap;
}
.prueba3{
  color: #fff!important;
    background-color: #32CD32!important;
    font-size: 18px!important;
        border: none;
    display: inline-block;
    outline: 0;
    padding: 8px 16px;
    vertical-align: middle;
    overflow: hidden;
    text-decoration: none;
    color: inherit;
    background-color: inherit;
    text-align: center;
    cursor: pointer;
    white-space: nowrap;
}
</style>

</html>
