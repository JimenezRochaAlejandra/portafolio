<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, user-scalable=no,initial-scale=1.0,minimun-scale=1.0">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="<?php echo e(URL::asset('css/hoja.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
        <title>PUNTO DE VENTA</title>

        <!-- Header with image -->
        <header class="bgimg w3-display-container w3-grayscale-min" id="home">
        <div class="w3-display-bottomleft w3-padding">
        
        
        </header>

        <div class="w3-row w3-center w3-border w3-border-dark-grey">
        <a href="javascript:void(0)" onclick="window.open('vista_producto.html')">
       </div>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <style>
        body, html {height: 100%}
        body,h1,h2,h3,h4,h5,h6 {font-family: "Amatic SC", sans-serif}
        .menu {display: none src="vista_producto.html"}
        .bgimg {
        background-repeat: no-repeat;
        background-size: cover;
       background-image: url("<?php echo e(asset('images/fondo.JPEG')); ?>");
        min-height: 90%;
        }
        </style>


        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                 text-align: center;
                width: 80%
                max-witdh: 1000px;
                margin: 0 auto;
                overflow: hidden;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            table {
             font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
            }

            th {
              color:#D5DDE5;;
              background:#1b1e24;
              border-bottom:4px solid #9ea7af;
              border-right: 1px solid #343a45;
              font-size:15px;
              font-weight: 100;
              padding:24px;
              text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
              vertical-align:middle;
              text-align:center;
            }

            th:first-child {
              border-top-left-radius:3px;
            }
             
            th:last-child {
              border-top-right-radius:3px;
              border-right:none;
            }
              
            tr {
              border-top: 1px solid #C1C3D1;
              border-bottom-: 1px solid #C1C3D1;
              color:#666B85;
              font-size:15px;
              font-weight:normal;
              text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);
            }
             
            tr:hover td {
              background:#4E5066;
              color:#FFFFFF;
              border-top: 1px solid #22262e;
            }
             
            tr:first-child {
              border-top:none;
            }

            tr:last-child {
              border-bottom:none;
            }
             
            tr:nth-child(odd) td {
              background:#EBEBEB;
            }
             
            tr:nth-child(odd):hover td {
              background:#4E5066;
            }

            tr:last-child td:first-child {
              border-bottom-left-radius:3px;
            }
             
            tr:last-child td:last-child {
              border-bottom-right-radius:3px;
            }
             
            td {
              background:#FFFFFF;
              padding:15px;
              text-align:center;
              vertical-align:middle;
              font-weight:300;
              font-size:15px;
              text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);
              border-right: 1px solid #C1C3D1;
            }

            td:last-child {
              border-right: 0px;
            }

            th.text-left {
              text-align: left;
            }

            th.text-center {
              text-align: center;
            }

            th.text-right {
              text-align: right;
            }

            td.text-left {
              text-align: left;
            }

            td.text-center {
              text-align: center;
            }

            td.text-right {
              text-align: right;
            }
            #div1 {
            overflow:scroll;
             height:400px;
            width:700px;
            background: white;
            }
            #div2 {
            height:400px;
            width:700px;
            margin-left: 24%;
            }
            label.eti {
             font-style:italic;
            font-weight:bold;
            font-size:1em;
            font-color:#ffffff;
            font-family:'Helvetica','Verdana','Monaco',sans-serif; 
            }
            input[type=text],input[type=password],input[type=number]{
            width: 200px; 
            height: 39px; 
            -webkit-border-radius: 0px 4px 4px 0px/5px 5px 4px 4px; 
            -moz-border-radius: 0px 4px 4px 0px/0px 0px 4px 4px; 
            border-radius: 0px 4px 4px 0px/5px 5px 4px 4px; 
            background-color: #fff; 
            -webkit-box-shadow: 1px 2px 5px rgba(0,0,0,.09); 
            -moz-box-shadow: 1px 2px 5px rgba(0,0,0,.09); 
            box-shadow: 1px 2px 5px rgba(0,0,0,.09); 
            border: solid 1px #cbc9c9;
            margin-left: -5px;
            margin-top: 13px; 
            padding-left: 10px;
}
        </style>
    </head>


    <body>
  <div class="contenedor">  
        <!-- Navbar (sit on top) -->
<div class="w3-top w3-hide-small">
  <div class="w3-bar w3-xlarge w3-black w3-opacity w3-hover-opacity-off" id="myNavbar">
    <a href="<?php echo e(route('dashboard')); ?>" class="w3-bar-item w3-button">INICIO</a>

     <a href="<?php echo e(route('products.index')); ?>" class="w3-bar-item w3-button " >PRODUCTOS </a> 
    <a href="<?php echo e(route('users.index')); ?>" class="w3-bar-item w3-button">USUARIOS</a>
    <a href="<?php echo e(route('employees.index')); ?>" class="w3-bar-item w3-button">EMPLEADOS</a>
    <a href="<?php echo e(route('sales.index')); ?>" class="w3-bar-item w3-button">VENTAS</a>
    
    <form method="POST" action="<?php echo e(route('logout')); ?>" >
         <?php echo e(csrf_field()); ?>

     <button class="w3-bar-item w3-button " style="margin-left: 200px">CERRAR SESION </button>
    </form>


  </div>
   <?php echo $__env->yieldContent('content'); ?>
</div>
      <footer class="w3-tag w3-xlarge">Abierto de 10am a 12pm</footer>  
</div>  
    </body>
</html>
