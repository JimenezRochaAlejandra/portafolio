<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amatic+SC">
        <link href="<?php echo e(URL::asset('css/cssnew_user.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
        <title>PUNTO DE VENTA</title>

        <!-- Header with image -->
        <header class="bgimg w3-display-container w3-grayscale-min" id="home">
        <div class="w3-display-bottomleft w3-padding">
        
        
        </header>

        <div class="w3-row w3-center w3-border w3-border-dark-grey">
        <a href="javascript:void(0)" onclick="window.open('vista_producto.html')">
       </div>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <style>
        body, html {height: 100%}
        body,h1,h2,h3,h4,h5,h6 {font-family: "Amatic SC", sans-serif}
        .menu {display: none src="vista_producto.html"}
        .bgimg {
        background-repeat: no-repeat;
        background-size: cover;
        background-image: url("47.jpg");
        min-height: 90%;
        }
        </style>


        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            table {
             font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
            }

            td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
            }

            tr:nth-child(even) {
            background-color: #dddddd;
            }
            #div1 {
            overflow:scroll;
             height:400px;
            width:700px;
            margin-left: 24%;
            }
            #div2 {
            height:400px;
            width:700px;
            margin-left: 24%;
            }
            label.eti {
             font-style:italic;
            font-weight:bold;
            font-size:1em;
            font-color:#ffffff;
            font-family:'Helvetica','Verdana','Monaco',sans-serif; 
            }
            input[type=text],input[type=password],input[type=number]{
            width: 200px; 
            height: 39px; 
            -webkit-border-radius: 0px 4px 4px 0px/5px 5px 4px 4px; 
            -moz-border-radius: 0px 4px 4px 0px/0px 0px 4px 4px; 
            border-radius: 0px 4px 4px 0px/5px 5px 4px 4px; 
            background-color: #fff; 
            -webkit-box-shadow: 1px 2px 5px rgba(0,0,0,.09); 
            -moz-box-shadow: 1px 2px 5px rgba(0,0,0,.09); 
            box-shadow: 1px 2px 5px rgba(0,0,0,.09); 
            border: solid 1px #cbc9c9;
            margin-left: -5px;
            margin-top: 13px; 
            padding-left: 10px;
}
        </style>
    </head>


    <body>
        <!-- Navbar (sit on top) -->
<div class="w3-top w3-hide-small">
  <div class="w3-bar w3-xlarge w3-black w3-opacity w3-hover-opacity-off" id="myNavbar">
    <a href="#" class="w3-bar-item w3-button">INICIO</a>

     <a href="<?php echo e(route('products.index')); ?>" class="w3-bar-item w3-button " >PRODUCTOS </a> 
    <a href="<?php echo e(route('users.index')); ?>" class="w3-bar-item w3-button">USUARIOS</a>
    <a href="<?php echo e(route('employees.index')); ?>" class="w3-bar-item w3-button">EMPLEADOS</a>
    <a class="w3-bar-item ">BIENVENIDO</a>
    <form method="POST" action="<?php echo e(route('logout')); ?>" >
         <?php echo e(csrf_field()); ?>

     <button class="w3-bar-item w3-button " >CERRAR SESION </button>
    </form>


  </div>
   <?php echo $__env->yieldContent('content'); ?>
</div>
      <footer class="w3-tag w3-xlarge">Abierto de 10am a 12pm</footer>  

    </body>
</html>
