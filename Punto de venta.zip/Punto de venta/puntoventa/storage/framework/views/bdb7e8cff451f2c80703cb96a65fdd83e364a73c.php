<!DOCTYPE HTML>

<HTML>
	<HEAD>
	
		<TITLE>Reportes
		</TITLE>
	</HEAD>
	<frameset rows="35%,*" frameborder="1">

    	<frame name="encabezado" src="<?php echo e(URL::to('frame/pagina1.blade.php')); ?>" bordercolor="#FF0000" marginwidth="10" marginheight="10" scrolling="no" noresize frameborder="0">
    <frameset cols="15%,*" >
      
      <frame src="<?php echo e(URL::asset('frame/vista_reporte.blade.php')); ?>"></frame>
      <frame src="<?php echo e(URL::asset('frame/tabla_reporte.blade.php')); ?>"></frame>
    </frameset >
    
  </frameset>

   
	<BODY>
		
	</BODY>
</HTML>
