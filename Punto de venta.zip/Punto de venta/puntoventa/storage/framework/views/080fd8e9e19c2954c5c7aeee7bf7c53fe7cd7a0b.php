<?php $__env->startSection('content'); ?>


<div class="testbox">
 
  <h1>Actualizar producto <?php echo e($producto->id); ?></h1>

  <form  method="POST" action="<?php echo e(route('products.update',$producto->id)); ?>">

  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

 <label id="name"  class="eti" name="name">Nombre del producto:</label> 
    <br>
  <label id="icon" for="name"></label>
  <input type="text" name="name_product" id="name" value="<?php echo e($producto->name_product); ?>" required/>
  
  <br>
  <label id="name"  class="eti" name="name">Marca:</label> 
    <br>
  <label id="icon" for="name"></label>
  <input type="text" name="mark" id="name" value="<?php echo e($producto->mark); ?>" required/>

  <br>
  <label id="name"  class="eti" name="name">Precio de venta:</label> 
    <br>
  
  <label id="icon" for="name"></label>
  <input type="number" step="any" name="sale_price" id="name" value="<?php echo e($producto->sale_price); ?>" required/>

  <br>
  <label id="name"  class="eti" name="name">Precio de compra:</label> 
    <br>
  <label id="icon" for="name"></label>
  <input type="number" step="any" name="purchase_price" id="name" value="<?php echo e($producto->purchase_price); ?>" required/>

   <br><br><button class="button" id="button"> Registrar</button>
  </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>