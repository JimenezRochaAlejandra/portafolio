<!DOCTYPE html>
<html lang="en">
<link href="<?php echo e(URL::asset('css/css_reporte_ventas.css')); ?>" rel="stylesheet">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>

<body >
<p>REPORTE DE VENTAS POR PERIODO</p>
<div>R.F.C TCH850701-RM1</div>
<div>Calzada Francisco I. Madero 1332</div>
<div>Col. Exmarquezado C.P. 68030</div>
<div>08/12/17 20:13</div>
<div>Teléfono: 9515327829 </div>
<br>
<table id="racetimes">
<tr id="firstrow">
  <th>ID VENTA</th>
  <th>NOMBRE PRODUCTO</th>
  <th>MARCA</th>
  <th>DESCRIPCIÓN</th>
  <th>CANTIDAD</th>
  <th>PRECIO</th>
  <th>TOTAL</th>
</tr>
<?php $acum=0;
 $acump=0;
  ?>
<?php for($n = 0; $n <sizeof($data); $n++): ?>
<?php $__currentLoopData = $data[$n]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
  <td><?php echo e($item->sales_id); ?></td>
  <td><?php echo e($item->name_product); ?></td>
  <td><?php echo e($item->mark); ?></td>
  <td><?php echo e($item->description); ?></td>
  <td><?php echo e($item->quantyti_product); ?></td>
  <td><?php echo e($item->sale_price); ?></td>
  <td><?php echo e($item->quantyti_product * $item->sale_price); ?></td>
  <?php
  $acum=$acum+( $item->quantyti_product * $item->sale_price) ;
  $acump=$acump+ $item->quantyti_product;
  ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endfor; ?>
<tr>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td>TOTAL$</td>
  <td> <?php echo e($acum); ?></td>
</tr>
</table>

<div>
En base a la tabla obtenida se ha determinado que el total de ganancias en esté periodo fue de : $ <?php echo e($acum); ?> vendiendo en total <?php echo e($acump); ?> producto(s).  
</div>
</body>
<script src="https://code.jquery.com/jquery-3.1.0.js"></script>
</html>