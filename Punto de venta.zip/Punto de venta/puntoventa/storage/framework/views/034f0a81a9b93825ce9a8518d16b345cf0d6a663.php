<?php $__env->startSection('content'); ?>
    
   <label> HOLA HERENCIA</label>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>