<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="<?php echo e(URL::asset('css/css_recibo.css')); ?>" >
  <title>Document</title>
</head>
<body>
  <IMG SRC="<?php echo e(asset('images/fondosoledad.jpg')); ?>">
  <p>R.F.C TCH850701-RM1</p>
  <p>Calzada Francisco I. Madero 1332</p>
  <p>Col. Exmarquezado C.P. 68030</p>
  <p><?php echo e($date); ?></p>
  <p>-----------------------------------------------------------------------------------</p>
<table id="racetimes">
<tr id="firstrow">
  <th>CANT.</th>
  <th>ARTICULO</th>
  <th>MARCA</th>
  <th>PRECIO</th>
  <th>TOTAL</th>
</tr>

<tbody >
           <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->quantyti_product); ?></td>
                <td><?php echo e($item->products_name); ?></td>
                <td><?php echo e($item->products_mark); ?></td>
                <td><?php echo e($item->products_price); ?></td>
                <td><?php echo e($item->products_price_total); ?></td>


             </tr> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>

<tr>
  <td></td>
	<td></td>
  <td></td>
	<td>TOTAL: $</td>
	<td><?php echo e($total_price); ?></td>
</tr>
</table>
<p>------------------------------------------------------------------------------------</p>
<p>LE ATENDIO: <?php echo e(Auth()->user()->name); ?></p>
<p>UN PLACER ATENDERLE</p>
</body>
</html>