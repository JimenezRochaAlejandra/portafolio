<?php $__env->startSection('content'); ?>


<div class="testbox">
  <h1>Actualizar Usuario <?php echo e($usuario->name); ?></h1>

  <form method="POST" action="<?php echo e(route('users.update',$usuario)); ?>">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PUT')); ?>

    <label id="name"  class="eti" name="name">Nombre de usuario:</label> 
    <br>
  <label id="icon" for="name"><i class="icon-envelope "></i></label>
  <input type="text" name="name" id="name" value="<?php echo e($usuario->name); ?>" placeholder="User Name" required/><br>
  <br>
  <label id="name"  class="eti" name="name">Contraseña:</label> 
    <br>
  <label id="icon" for="name"><i class="icon-user"></i></label>
  <input type="password" name="password" id="pas" placeholder="Password" required/>

  <label id="name"  class="eti" name="name">Confirme su contraseña:</label> 
    <br>

  <label id="icon" for="name"><i class="icon-shield"></i></label>
  <input type="password" name="confpas" id="confpas" placeholder="Confirm password" required/>
  <div class="tipo">
    
    <?php if($usuario->type=='administrador'): ?>
    
    <input type="radio" value="administrador" id="administrador" name="tipo" checked/>
    <label for="administrador" class="radio" chec>Administrador</label>
    <input type="radio" value="vendedor" id="vendedor" name="tipo"  />
    <label for="vendedor" class="radio">Vendedor</label>
    <?php endif; ?>
    <?php if($usuario->type=='vendedor'): ?>
    <input type="radio" value="administrador" id="administrador" name="tipo" />
    <label for="administrador" class="radio" chec>Administrador</label>
    <input type="radio" value="vendedor" id="vendedor" name="tipo" checked />
    <label for="vendedor" class="radio">Vendedor</label>
    <?php endif; ?>
    
   </div>
   
   <button class="button" id="button"> Registrar</button>
  
<br> <?php echo $errors-> first('name','<span class="help-block" style="color:red">:message</span>'); ?>

  </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>