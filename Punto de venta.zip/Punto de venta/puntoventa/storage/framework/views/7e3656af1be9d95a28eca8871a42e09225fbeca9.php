<?php $__env->startSection('content'); ?>

<div class="conteiner" id="div2">
  <div class="w3-container w3-blue">
  <h2>ACTUALIZAR DATOS DEL PRODUCTO <?php echo e($producto->id); ?></h2>
</div>

<form class="w3-container" method="POST" action="<?php echo e(route('products.update',$producto)); ?>" >
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>


  <p>
  <label>Nombre</label>
  <input class="w3-input" type="text" value="<?php echo e($producto->name_product); ?>" name="name_product"  required></p>
  <p>
  <label>Marca</label>
  <input class="w3-input" type="text" value="<?php echo e($producto->mark); ?>" name="mark" required></p>
  <button class="btn btn-info" type="submit" name="act" value="Actualizar" id="act" >
    Actualizar
  </button>
</form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>