<?php $__env->startSection('content'); ?>
	<div class="panel panel-default">
 
  <div class="panel-heading">
  	 
  </div>
  <div class="panel-body" >
  	<form method="GET" action="<?php echo e(route('employees.create')); ?>" >
     <button class="btn btn-info" style="margin-left: 42%" >AGREGAR EMPLEADO</button></td>
 </form>
  </div>
  <div class="panel-body">
  	<h2></h2>
  </div>
 <div id="div1">
  <table class="table table-striped">
        <thead>
          <th>ID</th>
          <th>NOMBRE</th>
          <th>APELLIDO</th>
          <th>SALARIO</th>
          <th>ACCIONES</th>

        </thead>
        <tbody>
          <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->last_name); ?></td>
                <td><?php echo e($item->salary); ?></td>
                <td> 
                  
                  <form method="GET" action="<?php echo e(route('employees.edit',$item->id)); ?>">
                    <button class="btn btn-info" >Actualizar</button>
                  </form>
                   
                  <form method="POST" action="<?php echo e(route('employees.destroy',$item->id)); ?>">
                     <?php echo e(csrf_field()); ?>

                     <?php echo e(method_field('DELETE')); ?>

                    <button class="btn btn-danger" onclick="return confirm('Esta seguro que desea eliminar a este usuario ?')">Eliminar</button>
                  </form> 
                </td>


             </tr> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
      </table>
  </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>