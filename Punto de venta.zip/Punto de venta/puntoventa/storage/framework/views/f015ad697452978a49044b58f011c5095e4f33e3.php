<!DOCTYPE HTML>

<HTML>
	<HEAD>
		<TITLE>
		</TITLE>
	</HEAD>

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<BODY>
	
	  <div class="w3-container w3-center">
		<h2>OPCIONES PRODUCTO</h2>
		<p><strong>opciones del administrador</strong></p>
		<div class="w3-bar">
<form method='POST' action="<?php echo e(route('/productos/agregar')); ?>">
	<?php echo e(csrf_field()); ?>	
 	 	<button  class="w3-button w3-black">Agregar Producto</button>
</form>
<form method='GET' action="<?php echo e(route('/productos/read')); ?>">
	<?php echo e(csrf_field()); ?>

  		<button  class="w3-button w3-teal">Mostrar Producto</button>
  	</form>
  		<button onclick="window.open('eliminar_producto.html')" class="w3-button w3-red">Eliminar Producto</button>
 	   </div>
       </div>
	
	</BODY>
</HTML>