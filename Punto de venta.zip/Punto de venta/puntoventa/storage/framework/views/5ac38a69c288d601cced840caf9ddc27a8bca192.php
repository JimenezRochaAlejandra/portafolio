<?php $__env->startSection('content'); ?>


<script language="Javascript" type="text/javascript" >
  
function obtenerDatos() {
 
 
  var json_sales_products= new Array();

  for (var i = 0; i < document.getElementById("tabla").rows.length-1; i++) {
    sale_product=new Object();

    sale_product.products_id=document.getElementById('tabla').tBodies[0].rows[i].cells[0].innerHTML;
    sale_product.products_name=document.getElementById('tabla').tBodies[0].rows[i].cells[1].innerHTML;
    sale_product.products_mark=document.getElementById('tabla').tBodies[0].rows[i].cells[2].innerHTML;


    sale_product.quantyti_product=document.getElementById('tabla').tBodies[0].rows[i].cells[3].innerHTML;
     sale_product.products_price=document.getElementById('tabla').tBodies[0].rows[i].cells[4].innerHTML;
    sale_product.products_price_total=document.getElementById('tabla').tBodies[0].rows[i].cells[5].innerHTML;
     


json_sales_products.push(sale_product);

  }
   var myString = JSON.stringify(json_sales_products);
  

  document.getElementById("oculto").value=myString;
   document.getElementById("ocult").value=cambiar2();
}
// sumar los datos de la tabla

function iniciarTabla() {
  tab = document.getElementById('tabla');
  filas = tab.getElementsByTagName('tr');
  for (i=1; fil = filas[i]; i++) {
    celdas = fil.getElementsByTagName('td');
    for (j=1; cel = celdas[j]; j++) {
      if (i>0 && j!=3) continue; // La última columna  y la última fila no se pueden editar
      cel.onclick = function() {crearInput(this)}


    } // end for j 

  } //end for i
}//end fuction

function eliminarFila() {
  arre= new Array(); 
 chk=document.getElementsByName('eliminar[]');

for(i=0;i<chk.length;i++)
{
   if(chk[i].checked){
    arre.push(i+1);
  }
}
for (var i = 0; i < arre.length; i++) {
  if(i==0)
  {
    document.getElementById("tabla").deleteRow(arre[i]);
    
  }
  else
  {
     document.getElementById("tabla").deleteRow(arre[i]-i);
    
  }
}
  


//alert(arre);
//document.getElementById("tabla").deleteRow(eliminarFila());
 cambiar(); 
}





function crearInput(celda) {
  celda.onclick = function() {return false}
  txt = celda.innerHTML;
  celda.innerHTML = '';
  var input=document.createElement('input');
  input.type="number";
  input.min="1";
  input.focus();
  obj = celda.appendChild(input);

  obj.value = txt;
  obj.focus();
  obj.onblur = function() {
    txt = this.value;
    celda.removeChild(obj);
    celda.innerHTML = txt;
    celda.onclick = function() {crearInput(celda)}
    sumar();
    cambiar();
        
  }
}


// sumar los datos de la tabla
function sumar() {
   tab = document.getElementById('tabla');
  filas = tab.getElementsByTagName('tr');
  for (i=1; fil = filas[i]; i++) {
    celdas = fil.getElementsByTagName('td');
    for (j=1; cel = celdas[j]; j++) {
      if (i>0 && j!=5) continue; 
       celdas[5].innerHTML = parseInt(celdas[3].innerHTML)*parseFloat(celdas[4].innerHTML);
    } // end for j 
  }
} // end function

function cambiar() {
  var acum=0;
   var la=document.getElementById('label');
  tab = document.getElementById('tabla');
  filas = tab.getElementsByTagName('tr');
  for (i=1; fil = filas[i]; i++) {
    celdas = fil.getElementsByTagName('td');
    for (j=1; cel = celdas[j]; j++) {
      if (i>0 && j!=5) continue; 
        acum=acum+parseFloat(celdas[5].innerHTML);
    } // end for j 
  }



 
  la.innerText="TOTAL:$"+acum;
}
function cambiar2() {
  var acum=0;
   var la=document.getElementById('label');
  tab = document.getElementById('tabla');
  filas = tab.getElementsByTagName('tr');
  for (i=1; fil = filas[i]; i++) {
    celdas = fil.getElementsByTagName('td');
    for (j=1; cel = celdas[j]; j++) {
      if (i>0 && j!=5) continue; 
        acum=acum+parseFloat(celdas[5].innerHTML);
    } // end for j 
  }



 
  return acum;
}
  function prueba() {
  
  //alert(document.getElementById('tabla').tBodies[0].rows[0].cells[1].innerHTML);
  //alert(document.getElementById("tabla").rows.length-1);
 var i;
 var o;
    for (var i = 0; i < document.getElementById("tabla").rows.length-1; i++) 
    {
      if (document.getElementById('tabla').tBodies[0].rows[i].cells[1].innerHTML==$('#a').val()) 
      {
        o=i;
        return o;
      }
    }
  return -1;
  }

  function hacer_click() {
    
   <?php
     $myPhpArray = $productos;
   ?>
   var myJsArray = <?= json_encode($myPhpArray); ?>;
   var i;
   var objeto;
   for (var i = 0; i < myJsArray.length; i++) {
     if ($('#a').val()==myJsArray[i].name_product) {
            objeto=myJsArray[i];
       }
   }

  return objeto;
  }
  function addProduct(e) {
  e.preventDefault();
  if (prueba()<0)
   {
    const row = createRow({
    id: hacer_click().id,
    name_product: $('#a').val(),
    mark: hacer_click().mark,
    cant:$('#cantidad').val(),
    price: hacer_click().sale_price,
    total_price: parseFloat(hacer_click().sale_price) * parseInt($('#cantidad').val())
    });


  $('table tbody').append(row);
  clean();
   }
   else
   {
    alert("el producto que desea ingresar ya esta en la tabla, si desea editar la cantidad de click en la celda");
    clean();
   }
   cambiar();
  iniciarTabla();
}

function createRow(data) {
  return (
    `<tr>` +
      `<td>${data.id}</td>` +
      `<td>${data.name_product}</td>` +
      `<td>${data.mark}</td>` +
      `<td>${data.cant}</td>` +
      `<td>${data.price}</td>` +
      `<td>${data.total_price}</td>` +
      `<td> <input type="checkbox" name="eliminar[]" style="width:20px;height:20px"></td>` +
    `</tr>`
  );
}

function clean() {
  $('#a').val('');
  $('#cantidad').val('');
  $('#a').focus();
}
</script>

 <img src="sale.png">
    <div id="envoltura">
      
        <div id="contenedor">
 
            <div id="cabecera" style="color: #fff ; font-weight: bold" >
               REGISTRO DE VENTA
            </div>
 
            <div id="cuerpo">

			
                <form id="form-login"  aligment=rigth onsubmit="addProduct(event)">
                                
					<p><label >  producto :</label></p>
                        <input list="browsers" id="a" name="browser">

                          <datalist id="browsers" name="datalist">
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item->name_product); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </datalist>


							  <p> </p>
 
                    <p><label>cantidad:</label></p>
                        <input name="cantid" type="number" min="1" id="cantidad" placeholder="Ingresa cantidad" required=""></p>
 
                    <p id="bot"><input type="submit" id="submit" name="submit" value="AGREGAR" class="boton"></p>
                </form>
            </div><!--fin cuerpo-->
 
            <div id="pie"></div>
        </div><!-- fin contenedor -->
       
    </div><!--fin envoltura-->

 <input type="submit" id="submit" name="submit" value="ELIMINAR" class="boton" onclick="eliminarFila()" style="margin-left: 700px">
<div class="panel-body">
    <h2></h2>
  </div>
 <div id="div1">
  <table class="table" id="tabla">
        <thead>
          <th>ID</th>
          <th>NOMBRE</th>
          <th>MARCA</th>
          <th>CANTIDAD</th>
          <th>PRECIO</th>
          <th>PRECIO TOTAL</th>
          <th>ACCION </th>

        </thead>
        <tbody class="table-hover">
         
            
          
        </tbody>
      </table>

  </div>

 <form id="form" method="POST" action="<?php echo e(route('sales.store')); ?>" onsubmit="obtenerDatos()"> 
 <?php echo e(csrf_field()); ?>

    
<div class="container">
  <div class="row">
    <div class="col-xs-12 col-md-3">
      <div class="form-group">
        <div class="input-group">
          
          <label class="eti" id="label" name="label" style="margin-left: 500px; font-size: 20px;">TOTAL:$0.0</label>
          
          <input type="hidden" name="datos"  id="oculto">
          <input type="hidden" name="total_price"  id="ocult">
          <input type="submit" id="enviar"  value="REALIZAR VENTA" class="boton" style="margin-left: 250px ; width: 130px">


        </div>
      </div>
    </div>
  </div>
</div>
</form>
</div>
<!--fin tabla-->
<script src="https://code.jquery.com/jquery-3.1.0.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendedor.principal.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>