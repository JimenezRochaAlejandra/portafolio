<?php $__env->startSection('content'); ?>

<div id="div1" style="height:350px ;width: 1000px;margin-left: 5%;">
  <table >
        <thead>
          <th>ID VENTA</th>
          <th>NOMBRE DEL PROEDUCTO</th>
          <th>MARCA</th>
          <th>DESCRIPCION</th>
          <th>PRECIO DE VENTA</th>
          <th>ACCIONES</th>
        </thead>
        <tbody class="table-hover">
          
        </tbody>
      </table>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>