<?php $__env->startSection('content'); ?>


<div class="testbox" style="width: 605px;height: 450px; ">
 
  <h1>Actualizar producto <?php echo e($producto->id); ?></h1>

  <form  method="POST" action="<?php echo e(route('products.update',$producto->id)); ?>">

  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

 &nbsp; <label class="eti" for="name">Nombre del producto:</label> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <label class="eti" for="name">Descripcion:</label>
  <br>
  <label id="icon" for="name"></label> <input type="text" name="name_product" id="name" placeholder="Nombre"  value="<?php echo e($producto->name_product); ?>" required/>
  &nbsp; &nbsp; <label id="icon" for="name"></label><input type="text" name="description" id="name" placeholder="Descripcion" value="<?php echo e($producto->description); ?>" required/>

  <br>
  &nbsp; <label class="eti" for="name">Marca:</label> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <label class="eti" for="name">Proveedor:</label>
  <br>
  <label id="icon" for="name"></label> <input type="text" name="mark" id="name" placeholder="Marca" value="<?php echo e($producto->mark); ?>" required/>
  &nbsp; &nbsp; <label id="icon" for="name"> </label><input type="text" name="provider" id="name" placeholder="Proveedor" value="<?php echo e($producto->provider); ?>" required/>

  <br><br>
  &nbsp; <label class="eti" for="name">Precio de venta:</label> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <label class="eti" for="name">Precio de compra:</label>
  <br> 
  <label id="icon" for="name"></label> <input type="number" min="0" step="any"  name="sale_price" id="name" placeholder="Precio de venta" value="<?php echo e($producto->sale_price); ?>" required/>&nbsp; &nbsp;  <label id="icon" for="name"> </label><input type="number" step="any" min="0" name="purchase_price" id="name" placeholder="Pecio de comprar" value="<?php echo e($producto->purchase_price); ?>" required/>

  <br><br>
  <label class="eti" for="name">Existencias:</label>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
  <br> 
  <label id="icon" for="name"></label><input type="number"  min="0" name="stock" id="name" placeholder="0" value="<?php echo e($producto->stock); ?>" required/>
  

   &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <button class="button"> Registrar</button>
  </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>