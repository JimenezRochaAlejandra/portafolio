<?php $__env->startSection('content'); ?>

<div class="contenedor" style="display: block;">
	<h3 style="color: black; font-size: 300%"> GENERADOR DE REPORTES </h3>
	<label style="color:black; font-size: 150%"> Seleccione las opciones que quiere que se realizen </label>

    <table class="table-fill" style="margin: 0 auto; width: 95%">
    	<tr>
    		<th></th>
    		<th></th>
    	</tr>
       <tbody>
    	<tr>
    		<td> REPORTE DE VENTAS POR DIA</td>
    		<td> <a href="<?php echo e(route('reports.dia')); ?>" class="btn btn-info">GENERAR </a> </td>
    	</tr>
    	<tr>
    		<td>REPORTE VENTAS POR PERIODO </td>
    		<td> <a href="<?php echo e(route('reports.mes')); ?>" class="btn btn-info">GENERAR</a> </td>
    	</tr>
    	<tr>
    		<td>REPORTE DE PRODUCTOS E INVERSION</td>
    		<td> <a href=" <?php echo e(route('reports.products')); ?> " class="btn btn-info">GENERAR</a> </td>
    	</tr>
    	<tr>
    		<td>REPORTE DE EMPLEADOS</td>
    		<td> <a href="<?php echo e(route('reports.employees')); ?>" class="btn btn-info">GENERAR</a> </td>
    	</tr>
       </tbody>	
    </table>
<script src="https://code.jquery.com/jquery-3.1.0.js"></script>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>