<?php $__env->startSection('content'); ?>

<?php if(Session::has('notice')): ?>
<div class="alert alert-dismissible alert-success col-lg-10 col-md-offset-1">
  <strong><?php echo e(Session::get('notice')); ?></strong>
  
  <ul class="nav navbar-nav navbar-right">

      <form method="GET" action="<?php echo e(route('users.index')); ?>" >
        <button class="btn btn-success btn-sm" >OK</button></td>
      </form>
   </ul>

</div>
<?php endif; ?>

  <div class="input-group">

     <a class="btn btn-info"  href="<?php echo e(route('users.create')); ?>" style="margin-left: 15%">AGREGAR USUARIO
     </a>
     <form style="margin-left: 45%">
        <input type="" placeholder="buscador.." name="busc">
       
          <button class="btn btn-info">BUSCAR</button>
        </form>  
      </div>

  <div class="panel-body">
  	<h2></h2>
  </div>
 <div id="div1">
  <table class="table">
        <thead>
          <th>ID</th>
          <th>NOMBRE</th>
          <th>TIPO</th>
          <th>ACCIONES</th>
        </thead>
        <tbody class="table-hover">
          <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->type); ?></td>
                <td> 
                  
                  <form method="GET" action="<?php echo e(route('users.edit',$item->id)); ?>">
                    <button class="btn btn-info" >Actualizar</button>
                  </form>
                   
                  <form method="POST" action="<?php echo e(route('users.destroy',$item->id)); ?>">
                     <?php echo e(csrf_field()); ?>

                     <?php echo e(method_field('DELETE')); ?>

                    <button class="btn btn-danger" onclick="return confirm('Esta seguro que desea eliminar a este usuario ?')">Eliminar</button>
                  </form> 
                </td>


             </tr> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
      </table>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>