<?php $__env->startSection('content'); ?>
<?php if(Session::has('notice')): ?>
<div class="alert alert-dismissible alert-success col-lg-10 col-md-offset-1">
  <strong><?php echo e(Session::get('notice')); ?></strong>
  
  <ul class="nav navbar-nav navbar-right">

      <form method="GET" action="<?php echo e(route('sales.index')); ?>" >
        <button class="btn btn-success btn-sm" >OK</button></td>
      </form>
   </ul>

</div>
<?php endif; ?>


 <div class="input-group">

    
     <form style="margin-left: 73%">
        <input type="date" placeholder="buscador.." name="busc">
       
          <button class="btn btn-info">BUSCAR</button>
        </form>  
      </div>
	<div class="panel panel-default">
 
  
  <div class="panel-body" >
  	<input type="hidden" name="">
  </div>
  <div class="panel-body">
  	<h2></h2>
  </div>
 <div id="div1">
  <table class="table">
        <thead>
          <th>ID VENTA</th>
          <th>NOMBRE DEL CAJERO</th>
          <th>FECHA VENTA</th>
          <th>ACCION </th>

        </thead>
        <tbody class="table-hover">
           <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->created_at); ?></td>
                <td> 
                  
                  <form method="GET" action="<?php echo e(route('sales.edit',$item->id)); ?>">
                    <button class="btn btn-info" >Actualizar</button>
                  </form>
                   
                  <form method="POST" action="<?php echo e(route('sales.destroy',$item->id)); ?>">
                     <?php echo e(csrf_field()); ?>

                     <?php echo e(method_field('DELETE')); ?>

                    <button class="btn btn-danger" onclick="return confirm('Esta seguro que desea eliminar esta venta ?')">Eliminar</button>
                  </form> 
                </td>


             </tr> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
      </table>
  </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>