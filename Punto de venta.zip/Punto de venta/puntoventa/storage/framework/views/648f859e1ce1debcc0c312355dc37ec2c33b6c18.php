<?php $__env->startSection('content'); ?>


<div class="testbox">
 
  <h1>Registrar producto</h1>

  <form  method="POST" action="<?php echo e(route('products.store')); ?>">

  <?php echo e(csrf_field()); ?>

 <label id="name"  class="eti" name="name">Nombre del producto:</label> 
    <br>
  <label id="icon" for="name"></label>
  <input type="text" name="name_product" id="name" placeholder="Nombre" required/>
  
  <br>
  <label id="name"  class="eti" name="name">Marca:</label> 
    <br>
  <label id="icon" for="name"></label>
  <input type="text" name="mark" id="name" placeholder="Marca" required/>

  <br>
  <label id="name"  class="eti" name="name">Precio de venta:</label> 
    <br>
  
  <label id="icon" for="name"></label>
  <input type="number" step="any" name="sale_price" id="name" placeholder="Precio de venta" required/>

  <br>
  <label id="name"  class="eti" name="name">Precio de compra:</label> 
    <br>
  <label id="icon" for="name"></label>
  <input type="number" step="any" name="purchase_price" id="name" placeholder="Precio de compra" required/>

   <br><br><button class="button" id="button"> Registrar</button>
  </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>