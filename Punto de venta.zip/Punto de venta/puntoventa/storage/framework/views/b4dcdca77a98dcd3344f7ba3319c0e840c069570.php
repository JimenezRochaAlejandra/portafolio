<?php $__env->startSection('content'); ?>

<form method="GET" action="<?php echo e(route('reports.detailsproducts')); ?>">
<button class="l" >GENERAR PDF</button>
</form>
<div id="div1" style="width: 90%;margin-left: 5%;">
  <table >
        <thead>
          <th>ID</th>
          <th>NOMBRE</th>
          <th>MARCA</th>
          <th>DESCRIPCION</th>
          <th>PROVEEDOR</th>
          <th>EXISTENCIAS</th>
          <th>PRECIO DE VENTA</th>
          <th>PRECIO DE COMPRA</th>
        </thead>
        <tbody class="table-hover">
          <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name_product); ?></td>
                <td><?php echo e($item->mark); ?></td>
                <td><?php echo e($item->description); ?></td>
                <td><?php echo e($item->provider); ?></td>
                <td><?php echo e($item->stock); ?></td>
                <td>$ <?php echo e($item->sale_price); ?></td>
                <td>$ <?php echo e($item->purchase_price); ?></td>
               
             </tr> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
      </table>
  </div>

  
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>