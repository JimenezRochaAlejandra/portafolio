<?php $__env->startSection('content'); ?>


<div class="testbox">
  <h1><br>Registrar Empleado</br></h1>

  <form method="POST" action="<?php echo e(route('employees.store')); ?>">
    <?php echo e(csrf_field()); ?>

  <label id="name"  class="eti" name="name">Nombre del empleado:</label> 
    <br>
  <label id="icon" for="name"><i class="icon-envelope "></i></label>
  <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre del empleado" required/><br>

  <br>
   <label id="name"  class="eti" name="name">Apellido(s):</label> 
    <br>
  <label id="icon" for="name"><i class="icon-user"></i></label>

  <input type="text" name="last_name" id="last_name" placeholder="Apellido(s)" required/><br>
  <br>
  <label id="name"  class="eti" name="name">Salario:</label> 
    <br>
  <label id="icon" for="name"><i class="icon-shield"></i></label>
  <input type="number" step="any" name="salary" id="confpas" placeholder="Salario" required/>
  
   <br>
   <button class="button" id="button"> Registrar</button>
  
<br> <?php echo $errors-> first('name','<span class="help-block" style="color:red">:message</span>'); ?>

  </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>