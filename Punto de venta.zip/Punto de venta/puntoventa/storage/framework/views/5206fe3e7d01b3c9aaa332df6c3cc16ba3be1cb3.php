<?php $__env->startSection('content'); ?>

<div class="conteiner" id="div2">
  <div class="w3-container w3-blue">
  <h2>DATOS PRODUCTO</h2>
</div>

<form class="w3-container" method="POST" action="<?php echo e(route('products.store')); ?>">
 <?php echo e(csrf_field()); ?>

  <p>
  <label>Nombre</label>
  <input class="w3-input" type="text" name="name_product" required></p>
  <p>
  <label>Marca</label>
  <input class="w3-input" type="text" name="mark" required></p>
  <button class="btn btn-info">
    Agregar
  </button>
</form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>