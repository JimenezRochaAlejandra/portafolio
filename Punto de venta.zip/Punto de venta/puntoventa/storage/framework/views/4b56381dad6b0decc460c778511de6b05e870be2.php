<html lang="en">
<head>
	<meta charset="utf-8" />
	<link href="<?php echo e(URL::asset('css/css_mostrar_ventas.css')); ?>" rel="stylesheet">
	<title>Table Style</title>
	<meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; width=device-width;">
</head>

<body>
<div class="table-title">
<h3>MOSTRAR VENTA</h3>
</div>
<table class="table-fill">
<thead>
<tr>
      <th>Id producto</th>
      <th>Nombre</th>
      <th>Marca</th>
      <th>Cantidad</th>
      <th>Precio</th>
      <th>Precio total</th>
      <th>Acción</th>
</tr>
</thead>
<tbody class="table-hover">

  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>

                <td><?php echo e($item->products_id); ?></td>
                

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
  

  </body>