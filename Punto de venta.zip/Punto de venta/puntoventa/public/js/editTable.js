
// sumar los datos de la tabla

function iniciarTabla() {
  tab = document.getElementById('tabla');
  filas = tab.getElementsByTagName('tr');
  for (i=1; fil = filas[i]; i++) {
    celdas = fil.getElementsByTagName('td');
    for (j=1; cel = celdas[j]; j++) {
      if (i>0 && j!=3) continue; // La última columna  y la última fila no se pueden editar
      cel.onclick = function() {crearInput(this)} 
    } // end for j 
  } //end for i
}//end fuction

function crearInput(celda) {
  celda.onclick = function() {return false}
  txt = celda.innerHTML;
  celda.innerHTML = '';
  var input=document.createElement('input');
  input.type="number";
  input.min="1";
  input.focus();
  obj = celda.appendChild(input);

  obj.value = txt;
  obj.focus();
  obj.onblur = function() {
    txt = this.value;
    celda.removeChild(obj);
    celda.innerHTML = txt;
    celda.onclick = function() {crearInput(celda)}
    sumar();
        
  }
}
// sumar los datos de la tabla
function sumar() {
   tab = document.getElementById('tabla');
  filas = tab.getElementsByTagName('tr');
  for (i=1; fil = filas[i]; i++) {
    celdas = fil.getElementsByTagName('td');
    for (j=1; cel = celdas[j]; j++) {
      if (i>0 && j!=5) continue; 
       celdas[celdas.length-1].innerHTML = parseInt(celdas[3].innerHTML)*parseFloat(celdas[4].innerHTML);
    } // end for j 
  }
} // end function
  function prueba() {
  
  //alert(document.getElementById('tabla').tBodies[0].rows[0].cells[1].innerHTML);
  //alert(document.getElementById("tabla").rows.length-1);
 var i;
 var o;
    for (var i = 0; i < document.getElementById("tabla").rows.length-1; i++) 
    {
      if (document.getElementById('tabla').tBodies[0].rows[i].cells[1].innerHTML==$('#a').val()) 
      {
        o=i;
        return o;
      }
    }
  return -1;
  }


  function hacer_click() {
    
   <?php
     $myPhpArray = $productos;
   ?>
   var myJsArray = <?= json_encode($myPhpArray); ?>;
   var i;
   var objeto;
   for (var i = 0; i < myJsArray.length; i++) {
     if ($('#a').val()==myJsArray[i].name_product) {
            objeto=myJsArray[i];
       }
   }

  return objeto;
  }

  function addProduct(e) {
  e.preventDefault();
  if (prueba()<0)
   {
    const row = createRow({
    id: hacer_click().id,
    name_product: $('#a').val(),
    mark: hacer_click().mark,
    cant:$('#cantidad').val(),
    price: hacer_click().sale_price,
    total_price: parseFloat(hacer_click().sale_price) * parseInt($('#cantidad').val())
    });
  $('table tbody').append(row);
  clean();
   }
   else
   {
    alert("el producto que desea ingresar ya esta en la tabla, si desea editar la cantidad de click en la celda");
   }
  iniciarTabla();
}

function createRow(data) {
  return (
    `<tr>` +
      `<td>${data.id}</td>` +
      `<td>${data.name_product}</td>` +
      `<td>${data.mark}</td>` +
      `<td>${data.cant}</td>` +
      `<td>${data.price}</td>` +
      `<td>${data.total_price}</td>` +
    `</tr>`
  );
}

function clean() {
  $('#a').val('');
  $('#cantidad').val('');
  $('#a').focus();
}