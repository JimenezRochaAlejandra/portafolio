@extends('dashboard')

@section('content')


<div class="testbox" style="width: 80.5%;height: 45%; ">
 
  <h1>Actualizar producto {{ $producto->id }}</h1>

  <form  method="POST" action="{{ route('products.update',$producto->id) }}">

  {{ csrf_field() }}
  {{ method_field('PUT') }}
 &nbsp; <label class="eti" for="name">Nombre del producto:</label> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <label class="eti" for="name">Descripción:</label>
  <br>
  <label id="icon" for="name"></label> <input type="text" name="name_product" id="name" placeholder="Nombre"  value="{{ $producto->name_product }}" required/>
  &nbsp; &nbsp; <label id="icon" for="name"></label><input type="text" name="description" id="name" placeholder="Descripcion" value="{{ $producto->description }}" required/>

  <br>
  &nbsp; <label class="eti" for="name">Marca:</label> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <label class="eti" for="name">Proveedor:</label>
  <br>
  <label id="icon" for="name"></label> <input type="text" name="mark" id="name" placeholder="Marca" value="{{ $producto->mark }}" required/>
  &nbsp; &nbsp; <label id="icon" for="name"> </label><input type="text" name="provider" id="name" placeholder="Proveedor" value="{{ $producto->provider }}" required/>

  <br><br>
  &nbsp; <label class="eti" for="name">Precio de venta:</label> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <label class="eti" for="name">Precio de compra:</label>
  <br> 
  <label id="icon" for="name"></label> <input type="number" min="0" step="any"  name="sale_price" id="name" placeholder="Precio de venta" value="{{ $producto->sale_price }}" required/>&nbsp; &nbsp;  <label id="icon" for="name"> </label><input type="number" step="any" min="0" name="purchase_price" id="name" placeholder="Pecio de comprar" value="{{ $producto->purchase_price }}" required/>

  <br><br>
  <label class="eti" for="name">Existencias:</label>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
  <br> 
  <label id="icon" for="name"></label><input type="number"  min="0" name="stock" id="name" placeholder="0" value="{{ $producto->stock }}" required/>
  

   &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <button class="button"> Registrar</button>
  </form>
</div>

@endsection