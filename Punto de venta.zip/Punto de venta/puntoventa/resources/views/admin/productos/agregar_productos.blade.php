@extends('dashboard')

@section('content')


<div class="testbox" style="width: 60.5%;height: 45%; ">
  <h1>Registrar producto </h1>

  <form method="POST" action="{{ route('products.store') }}">
{{ csrf_field() }}
  &nbsp; <label class="eti" for="name">Nombre del producto:</label> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <label class="eti" for="name">Descripcion:</label>
  <br>
  <label id="icon" for="name"></label> <input type="text" name="name_product" id="name" placeholder="Nombre" required/>
  &nbsp; &nbsp; <label id="icon" for="name"></label><input type="text" name="description" id="name" placeholder="Descripcion" required/>

  <br>
  &nbsp; <label class="eti" for="name">Marca:</label> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <label class="eti" for="name">Proveedor:</label>
  <br>
  <label id="icon" for="name"></label> <input type="text" name="mark" id="name" placeholder="Marca" required/>
  &nbsp; &nbsp; <label id="icon" for="name"> </label><input type="text" name="provider" id="name" placeholder="Proveedor" required/>

  <br><br>
  &nbsp; <label class="eti" for="name">Precio de venta:</label> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <label class="eti" for="name">Precio de compra:</label>
  <br> 
  <label id="icon" for="name"></label> <input type="number" min="0" step="any"  name="sale_price" id="name" placeholder="Precio de venta" required/>&nbsp; &nbsp;  <label id="icon" for="name"> </label><input type="number" step="any" min="0" name="purchase_price" id="name" placeholder="Pecio de comprar" required/>

  <br><br>
  <label class="eti" for="name">Existencias:</label>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
  <br> 
  <label id="icon" for="name"></label><input type="number"  min="0" name="stock" id="name" placeholder="0" required/>
  

   &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <button class="button"> Registrar</button>
  </form>
</div>

@endsection