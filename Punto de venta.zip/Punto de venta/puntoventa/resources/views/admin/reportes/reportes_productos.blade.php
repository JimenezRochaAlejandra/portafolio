@extends('dashboard')
@section('content')

<form method="GET" action="{{ route('reports.detailsproducts') }}">
<button class="l" >GENERAR PDF</button>
</form>
<div id="div1" style="width: 90%;margin-left: 5%;">
  <table >
        <thead>
          <th>ID</th>
          <th>NOMBRE</th>
          <th>MARCA</th>
          <th>DESCRIPCION</th>
          <th>PROVEEDOR</th>
          <th>EXISTENCIAS</th>
          <th>PRECIO DE VENTA</th>
          <th>PRECIO DE COMPRA</th>
        </thead>
        <tbody class="table-hover">
          @foreach($productos as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->name_product }}</td>
                <td>{{ $item->mark }}</td>
                <td>{{ $item->description }}</td>
                <td>{{ $item->provider }}</td>
                <td>{{ $item->stock }}</td>
                <td>$ {{ $item->sale_price  }}</td>
                <td>$ {{ $item->purchase_price }}</td>
               
             </tr> 
          @endforeach 
        </tbody>
      </table>
  </div>

  
</div>

@endsection
