<!DOCTYPE html>
<html lang="en">
<link href="{{ URL::asset('css/css_reporte_ventas.css') }}" rel="stylesheet">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body >
<p>REPORTE DE VENTAS POR DÍA</p>
<div>R.F.C TCH850701-RM1</div>
<div>Calzada Francisco I. Madero 1332</div>
<div>Col. Exmarquezado C.P. 68030</div>
<div>08/12/17 20:13</div>
<div>Teléfono: 9515327829 </div>
<br>
<table id="racetimes">
<tr id="firstrow">
          <th>ID</th>
          <th>NOMBRE</th>
          <th>MARCA</th>
          <th>DESCRIPCION</th>
          <th>PROVEEDOR</th>
          <th>EXISTENCIAS</th>
          <th>PRECIO DE VENTA</th>
          <th>PRECIO DE COMPRA</th>
</tr>
<?php $acum=0;
 $acumto=0;
 $acump=0;
 $acumpr=0;
 $acumtoo=0;
  ?> 
  @foreach($data as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->name_product }}</td>
                <td>{{ $item->mark }}</td>
                <td>{{ $item->description }}</td>
                <td>{{ $item->provider }}</td>
                <td>{{ $item->stock }}</td>
                <td>$ {{ $item->sale_price  }}</td>
                <td>$ {{ $item->purchase_price }}</td>
               <?php
                $acum=$acum+ $item->sale_price ;
                $acump=$acump+ $item->purchase_price;
                $acumpr=$acumpr+$item->stock;
                $acumto=$acumto+($item->stock * $item->sale_price);
                $acumtoo=$acumtoo+($item->stock * $item->purchase_price);
               ?>
             </tr> 
          @endforeach
<tr>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td>TOTAL$</td>
  <td>{{ $acumpr }}</td>
  <td> {{ $acum }}</td>
  <td> {{ $acump }}</td>
</tr>
</table>

<div>
En base a la tabla obtenida se ha determinado que el total  de productos en la tienda es de {{$acumpr}}. Se espera una ganancia total de ${{ $acumto }}. La inversion que se ha hecho es de $ {{ $acumtoo }}, por lo que se espera que la ganancia neta sea de  ${{ $acumto-$acumtoo }}  
</div>
</body>
<script src="https://code.jquery.com/jquery-3.1.0.js"></script>
</html>