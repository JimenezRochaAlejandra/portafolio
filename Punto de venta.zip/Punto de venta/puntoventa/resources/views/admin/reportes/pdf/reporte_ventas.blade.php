<!DOCTYPE html>
<html lang="en">
<link href="{{ URL::asset('css/css_reporte_ventas.css') }}" rel="stylesheet">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<script type="text/javascript">
function cambiar() {
  var acum=0;
  var la=document.getElementById('label'); 
  tab = document.getElementById('racetimes');
  filas = tab.getElementsByTagName('tr');
  for (i=1; fil = filas[i]; i++) {
    celdas = fil.getElementsByTagName('td');
    for (j=1; cel = celdas[j]; j++) {
      if (i>0 && j!=6) continue; 
        acum=acum+parseFloat(celdas[5].innerHTML);
    } // end for j 
  }



 
return acum;
}
</script>
<body >
<p>REPORTE DE VENTAS POR DÍA</p>
<div>R.F.C TCH850701-RM1</div>
<div>Calzada Francisco I. Madero 1332</div>
<div>Col. Exmarquezado C.P. 68030</div>
<div>08/12/17 20:13</div>
<div>Teléfono: 9515327829 </div>
<br>
<table id="racetimes">
<tr id="firstrow">
  <th>ID VENTA</th>
  <th>NOMBRE PRODUCTO</th>
  <th>MARCA</th>
  <th>DESCRIPCIÓN</th>
  <th>CANTIDAD</th>
  <th>PRECIO</th>
  <th>TOTAL</th>
</tr>
<?php $acum=0;
 $acump=0;
  ?>
@for($n = 0; $n <sizeof($data); $n++)
@foreach($data[$n] as $item)

<tr>
  <td>{{ $item->sales_id }}</td>
  <td>{{ $item->name_product }}</td>
  <td>{{ $item->mark }}</td>
  <td>{{ $item->description }}</td>
  <td>{{ $item->quantyti_product }}</td>
  <td>{{ $item->sale_price }}</td>
  <td>{{ $item->quantyti_product * $item->sale_price }}</td>
  <?php
  $acum=$acum+( $item->quantyti_product * $item->sale_price) ;
  $acump=$acump+ $item->quantyti_product;
  ?>
</tr>
@endforeach
@endfor
<tr>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td>TOTAL$</td>
  <td> {{ $acum }}</td>
</tr>
</table>

<div>
En base a la tabla obtenida se ha determinado que el total de ganancias en esté día fue de : $ {{$acum}} vendiendo en total {{$acump}} producto(s).  
</div>
</body>
<script src="https://code.jquery.com/jquery-3.1.0.js"></script>
</html>