<!DOCTYPE html>
<html lang="en">
<link href="{{ URL::asset('css/css_reporte_ventas.css') }}" rel="stylesheet">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body >
<p>REPORTE DE VENTAS POR DÍA</p>
<div>R.F.C TCH850701-RM1</div>
<div>Calzada Francisco I. Madero 1332</div>
<div>Col. Exmarquezado C.P. 68030</div>
<div>08/12/17 20:13</div>
<div>Teléfono: 9515327829 </div>
<br>
<table id="racetimes">
<tr id="firstrow">
          <th>ID</th>
          <th>NOMBRE</th>
          <th>APELLIDO</th>
          <th>SALARIO</th>
</tr>
<?php $acum=0;
 
  ?> 
  @foreach($data as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ $item->last_name }}</td>
                <td>$ {{ $item->salary }}</td>
             <?php
             $acum=$acum+$item->salary ;
            
  ?>

             </tr> 
          @endforeach 
<tr>
  <td></td>
  <td></td>
  <td>TOTAL</td>
  <td>${{ $acum }}</td>
</tr>
</table>

<div>
En base a la tabla obtenida se ha determinado que se gasta ${{ $acum }} en el pago a los empleados quincenalmente</div>
</body>
<script src="https://code.jquery.com/jquery-3.1.0.js"></script>
</html>