@extends('dashboard')
@section('content')

<script language="Javascript" type="text/javascript" >
   function obtenerDatos() {
 
 
  var json_sales= new Array();

  for (var i = 0; i < document.getElementById("tabla").rows.length-1; i++) {
    sale=new Object();

    sale.sale_id=document.getElementById('tabla').tBodies[0].rows[i].cells[0].innerHTML;
    sale.sale_date=document.getElementById('tabla').tBodies[0].rows[i].cells[1].innerHTML;
    sale.sale_name_user=document.getElementById('tabla').tBodies[0].rows[i].cells[2].innerHTML;

json_sales.push(sale);

  }

   var myString = JSON.stringify(json_sales);
  document.getElementById("oculto").value=myString;
}
</script>  
<br>
<br>
<div class="row" >
  <h3 align="center"></h3>
  <div class="column side" align="left" >

     <form method="GET" action="{{ route('reports.dia') }}">
    <div class="input-group">
    <label class="eti">Seleccione la fecha:</label>  
    <input type="date" name="fecha" >

    </div>  
      

      
      
      <button class="l"  style="margin-left: 30%">Aceptar</button>
      </form>
 <br>
 <br>
 <br>
        <form method="GET" action="{{ route('reports.detailsdias') }}" onsubmit="obtenerDatos()">
         <label class="eti">De click en el boton para gener el PDF:</label> <br>
         <input type="hidden" name="datos" id="oculto">
        <button class="l" onclick="obtenerDatos()" >GENERAR PDF</button>
        </form>
    </div>
<div class="content" id="div1" style="width: 50%;margin-right:1% ">
      
<table class="table" id="tabla">
  <thead>
    <td>ID VENTA</td>
    <td>FECHA DE VENTA</td>
    <td>NOMBRE DEL PRODUCTO </td>
    
  
  </thead>
  <tbody class="table-hover">
          @foreach($venta_producto as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->created_at }}</td>
                <td>{{ $item->name }}</td>
               
             </tr> 
          @endforeach 
        </tbody>
</table>

    </div>

  
</div>

@endsection
