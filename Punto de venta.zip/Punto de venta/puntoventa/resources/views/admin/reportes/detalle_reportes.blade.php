@extends('dashboard')

@section('content')

<div id="div1" style="height:35% ;width: 100%;margin-left: 5%;">
  <table >
        <thead>
          <th>ID VENTA</th>
          <th>NOMBRE DEL PRODUCTO</th>
          <th>MARCA</th>
          <th>DESCRIPCION</th>
          <th>PRECIO DE VENTA</th>
          <th>ACCIONES</th>
        </thead>
        <tbody class="table-hover">
          
        </tbody>
      </table>
  </div>


@endsection