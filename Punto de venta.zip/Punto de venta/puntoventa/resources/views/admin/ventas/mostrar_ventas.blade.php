@extends('dashboard')

@section('content')
@if(Session::has('notice'))
<div class="alert alert-dismissible alert-success col-lg-10 col-md-offset-1">
  <strong>{{ Session::get('notice') }}</strong>
  
  <ul class="nav navbar-nav navbar-right">

      <form method="GET" action="{{ route('sales.index') }}" >
        <button class="btn btn-success btn-sm" >OK</button></td>
      </form>
   </ul>

</div>
@endif


 <div class="input-group">

    
     <form style="margin-left: 73%">
        <input type="date" placeholder="buscador.." name="busc">
       
          <button class="btn btn-info">BUSCAR</button>
        </form>  
      </div>
	<div class="panel panel-default">
 
  
  <div class="panel-body" >
  	<input type="hidden" name="">
  </div>
  <div class="panel-body">
  	<h2></h2>
  </div>
 <div id="div1">
  <table class="table">
        <thead>
          <th>ID VENTA</th>
          <th>NOMBRE DEL CAJERO</th>
          <th>FECHA VENTA</th>
          <th>ACCION </th>

        </thead>
        <tbody class="table-hover">
           @foreach($ventas as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ $item->created_at }}</td>
                <td> 
                  
                  <form method="GET" action="{{ route('sales.edit',$item->id) }}">
                    <button class="btn btn-info" >Actualizar</button>
                  </form>
                   
                  <form method="POST" action="{{ route('sales.destroy',$item->id) }}">
                     {{ csrf_field() }}
                     {{ method_field('DELETE') }}
                    <button class="btn btn-danger" onclick="return confirm('Esta seguro que desea eliminar esta venta ?')">Eliminar</button>
                  </form> 
                </td>


             </tr> 
          @endforeach 
        </tbody>
      </table>
  </div>

</div>

@endsection