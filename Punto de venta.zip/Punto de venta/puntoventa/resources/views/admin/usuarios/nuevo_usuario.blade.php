@extends('dashboard')

@section('content')


<div class="testbox">
  <h1>Registrar Usuario</h1>

  <form method="POST" action="{{ route('users.store')}}">
    {{ csrf_field() }}

    <label id="name"  class="eti" name="name">Nombre de usuario:</label> 
    <br>
  <label id="icon" for="name"><i class="icon-envelope "></i></label>
  <input type="text" name="name" id="name" value="{{ old('name')}}" placeholder="User Name" required/><br>
  <br>

  <label id="name"  class="eti" name="name">Contraseña:</label> 
    <br>
   <label id="name" for="name"><i class="icon-user"></i></label>
  <label id="icon" for="name"><i class="icon-user"></i></label>

  <input type="password" name="password" id="pas" placeholder="Password" required/>
  <br>


  <label id="name"  class="eti" name="name">Confirme su contraseña:</label> 
    <br>
  <label id="icon" for="name"><i class="icon-shield"></i></label>
  <input type="password" name="confpas" id="confpas" placeholder="Confirm password" required/>
  <div class="tipo">
    
    <input type="radio" value="administrador" id="administrador" name="tipo" checked/>
    <label for="administrador" class="radio" chec>Administrador</label>
    <input type="radio" value="vendedor" id="vendedor" name="tipo" />
    <label for="vendedor" class="radio">Vendedor</label>
   </div>
   
   <button class="button" id="button"> Registrar</button>
  
<br> {!! $errors-> first('name','<span class="help-block" style="color:red">:message</span>') !!}
  </form>
</div>

@endsection