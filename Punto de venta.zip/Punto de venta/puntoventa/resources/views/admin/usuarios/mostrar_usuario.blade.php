@extends('dashboard')

@section('content')

@if(Session::has('notice'))
<div class="alert alert-dismissible alert-success col-lg-10 col-md-offset-1">
  <strong>{{ Session::get('notice') }}</strong>
  
  <ul class="nav navbar-nav navbar-right">

      <form method="GET" action="{{ route('users.index') }}" >
        <button class="btn btn-success btn-sm" >OK</button></td>
      </form>
   </ul>

</div>
@endif

  <div class="input-group">

     <a class="btn btn-info"  href="{{ route('users.create') }}" style="margin-left: 15%">AGREGAR USUARIO
     </a>
     <form style="margin-left: 45%">
        <input type="" placeholder="buscador.." name="busc">
       
          <button class="btn btn-info">BUSCAR</button>
        </form>  
      </div>

  <div class="panel-body">
  	<h2></h2>
  </div>
 <div id="div1">
  <table class="table">
        <thead>
          <th>ID</th>
          <th>NOMBRE</th>
          <th>TIPO</th>
          <th>ACCIONES</th>
        </thead>
        <tbody class="table-hover">
          @foreach($usuarios as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ $item->type }}</td>
                <td> 
                  
                  <form method="GET" action="{{ route('users.edit',$item->id) }}">
                    <button class="btn btn-info" >Actualizar</button>
                  </form>
                   
                  <form method="POST" action="{{ route('users.destroy',$item->id) }}">
                     {{ csrf_field() }}
                     {{ method_field('DELETE') }}
                    <button class="btn btn-danger" onclick="return confirm('Esta seguro que desea eliminar a este usuario ?')">Eliminar</button>
                  </form> 
                </td>


             </tr> 
          @endforeach 
        </tbody>
      </table>
  </div>

</div>
@endsection