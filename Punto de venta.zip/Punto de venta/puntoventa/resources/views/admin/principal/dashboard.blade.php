@extends('dashboard')

@section('content')

    <h1 style="color: BLACK;">BIENVENIDO {{ Auth()->user()->name }}</h1>

    <h3 style="color: BLACK;font-size: 300%;font-weight: bold; ">TIENDA DE ABARROTES "LA SOLEDAD"</h3>
@endsection
