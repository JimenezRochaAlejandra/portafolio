<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="{{ URL::asset('css/css_recibo.css') }}" >
  <title>Document</title>
</head>
<body>
  <IMG SRC="{{ asset('images/fondosoledad.jpg') }}">
  <p>R.F.C TCH850701-RM1</p>
  <p>Calzada Francisco I. Madero 1332</p>
  <p>Col. Exmarquezado C.P. 68030</p>
  <p>{{ $date }}</p>
  <p>-----------------------------------------------------------------------------------</p>
<table id="racetimes">
<tr id="firstrow">
  <th>CANT.</th>
  <th>ARTICULO</th>
  <th>MARCA</th>
  <th>PRECIO</th>
  <th>TOTAL</th>
</tr>

<tbody >
           @foreach($data as $item)
            <tr>
                <td>{{ $item->quantyti_product }}</td>
                <td>{{ $item->products_name }}</td>
                <td>{{ $item->products_mark }}</td>
                <td>{{ $item->products_price }}</td>
                <td>{{ $item->products_price_total}}</td>


             </tr> 
          @endforeach 
        </tbody>

<tr>
  <td></td>
	<td></td>
  <td></td>
	<td>TOTAL: $</td>
	<td>{{ $total_price }}</td>
</tr>
</table>
<p>------------------------------------------------------------------------------------</p>
<p>LE ATENDIO: {{ Auth()->user()->name }}</p>
<p>UN PLACER ATENDERLE</p>
</body>
</html>