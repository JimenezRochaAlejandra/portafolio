-- MySQL dump 10.13  Distrib 5.7.12, for Win32 (AMD64)
--
-- Host: localhost    Database: puntoventa
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary` double(8,2) NOT NULL,
  `direccion` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `puesto` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `flag` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Samuel','Perez Lopez',6500.50,'Santa Rosa 504 Loma Bonita','gerente','2000-01-27','1',NULL,'2018-06-06 08:30:11'),(2,'Marcos','Lopez Martinez',4850.50,'Santa','gerente','0000-00-00','1',NULL,NULL),(3,'Jorge','Ramirez Antonio',3850.50,'Santa','gerente','0000-00-00','1',NULL,NULL),(4,'Pablo','Luna Martinez',5500.70,'Santa','gerente','0000-00-00','1',NULL,NULL),(5,'paola','lopez',1500.00,'privada','gerente','2018-06-21','0','2018-06-05 03:02:47','2018-06-05 03:05:16'),(6,'a','aa5',555.00,'ttgg','g4tg4','2018-06-06','0','2018-06-05 03:04:10','2018-06-05 03:05:03'),(7,'gggg','hola',43434.00,'4r34','45tg54','2018-06-13','0','2018-06-05 03:04:52','2018-06-05 03:05:11'),(8,'ingrid','lopez',1800.00,'privada fernandez','almacenista','2000-06-07','0','2018-06-06 08:28:56','2018-06-06 08:29:53'),(9,'paola','niño',1800.00,'gnjrghruihureh','almacenista','2018-06-21','0','2018-06-07 07:15:06','2018-06-07 07:15:18');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_100000_create_password_resets_table',1),(2,'2017_10_27_021411_create_users_table',1),(3,'2017_11_17_000625_create_employees_table',1),(4,'2017_11_19_184924_create_products_table',1),(5,'2017_12_02_042108_create_sales_table',1),(6,'2017_12_02_042512_create_sales_products_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_product` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mark` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_provider` int(10) NOT NULL,
  `provider` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `purchase_price` double(8,2) NOT NULL,
  `wholesale_price` double(8,2) NOT NULL,
  `sale_price` double(8,2) NOT NULL,
  `flag` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_provider_idx` (`id_provider`),
  CONSTRAINT `idprovider` FOREIGN KEY (`id_provider`) REFERENCES `providers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Galleta Surtido Rico','Gamesa','516 grs',1,'PEPSICO',30,32.56,36.60,38.30,'1',NULL,NULL),(2,'Harina para Hot Cakes','Gamesa','850 grs',1,'PEPSICO',45,22.10,25.10,28.10,'1',NULL,NULL),(3,'Surtido Rico','Gamesa','500 grs',1,'PEPSICO',88,35.67,38.30,40.10,'1',NULL,NULL),(4,'Galletas Chokis','Gamesa','63 grs',1,'PEPSICO',34,5.34,7.81,9.23,'1',NULL,NULL),(5,'Marias','Gamesa','170 grs',1,'PEPSICO',23,7.10,8.25,10.00,'1',NULL,NULL),(6,'Galletas Crackets','Gamesa','95 grs',1,'PEPSICO',18,5.43,7.60,9.13,'1',NULL,NULL),(7,'Galletas Maria','Gamesa','850 grs',1,'PEPSICO',42,38.94,41.63,43.12,'1',NULL,NULL),(8,'Saladitas','Gamesa','13 grs',1,'PEPSICO',50,3.40,5.75,7.10,'1',NULL,NULL),(9,'Galletas Emperador','Gamesa','101 grs',1,'PEPSICO',20,8.10,9.37,11.30,'1',NULL,NULL),(10,'Galletas Chokis','Gamesa','199 grs',1,'PEPSICO',100,12.45,14.64,16.29,'1',NULL,NULL),(11,'Galletas Ricanela','Gamesa','113 grs',1,'PEPSICO',38,7.38,9.30,11.90,'1',NULL,NULL),(12,'Harina Hot Cakes Aunt Jemima','Quaker','500 grs',1,'PEPSICO',56,24.28,26.46,28.28,'1',NULL,NULL),(13,'Refresco Mirinda','Mirinda','2.5 lt',1,'PEPSICO',24,20.15,22.68,24.96,'1',NULL,NULL),(14,'Sabritas Doritos','Sabritas','46 grs',1,'PEPSICO',29,7.18,9.16,10.90,'1',NULL,NULL),(15,'Galletas Emperador Combinado','Gamesa','101 grs',1,'PEPSICO',64,8.00,9.37,11.54,'1',NULL,NULL),(16,'Galletas Cremax Fresa','Gamesa','213 grs',1,'PEPSICO',88,12.33,15.00,18.43,'1',NULL,NULL),(17,'Habaneras Integral','Gamesa','117 grs',1,'PEPSICO',34,5.19,8.75,11.20,'1',NULL,NULL),(18,'Galletas Emperador Piruetas','Gamesa','106 grs',1,'PEPSICO',23,7.34,9.37,11.94,'1',NULL,NULL),(19,'Galletas Emperador Senzo','Gamesa','93 grs',1,'PEPSICO',38,5.16,7.67,10.37,'1',NULL,NULL),(20,'Papas Sabritas','Sabritas','55 grs',1,'PEPSICO',84,8.93,9.84,10.23,'1',NULL,NULL),(21,'Sabritas Pake Taxo','Sabritas','70 grs',1,'PEPSICO',69,7.20,9.80,11.86,'1',NULL,NULL),(22,'Saladitas','Gamesa','137 grs',1,'PEPSICO',39,5.12,8.61,10.45,'1',NULL,NULL),(23,'Gatorade naranja','Gatorade','1 lt',1,'PEPSICO',46,16.23,20.91,22.75,'1',NULL,NULL),(24,'Gatorade Limonada','Gatorade','1 lt',1,'PEPSICO',85,16.23,20.91,22.75,'1',NULL,NULL),(25,'Refresco Manzanita Sol Lata','Manzanita Sol','355 ml',1,'PEPSICO',98,5.45,7.00,9.23,'1',NULL,NULL),(26,'Galletas Populares','Gamesa','1 kg',1,'PEPSICO',10,30.24,33.76,34.56,'1',NULL,NULL),(27,'Galletas Fruts de Arcoiris','Gamesa','104 grs',1,'PEPSICO',23,8.34,10.45,12.37,'1',NULL,NULL),(28,'Galletas Chokis','Gamesa','441 grs',1,'PEPSICO',16,37.90,39.64,43.10,'1',NULL,NULL),(29,'Gatorade Uva','Gatorade','500 ml',1,'PEPSICO',25,12.30,15.18,18.30,'1',NULL,NULL),(30,'Refresco Seven Up','Seven Up','2.5 lt',1,'PEPSICO',103,20.86,23.75,25.75,'1',NULL,NULL),(31,'Refresco Manzanita Sol','Manzanita Sol','600 ml',1,'PEPSICO',100,7.13,9.53,11.76,'1',NULL,NULL),(32,'Galletas Emperador Chocolate','Gamesa','486 grs',1,'PEPSICO',86,30.45,36.25,38.10,'1',NULL,NULL),(33,'Galletas Arcoiris multipack','Gamesa','185 grs',1,'PEPSICO',45,15.10,17.85,19.35,'1',NULL,NULL),(34,'Galletas Emperador Zentro','Gamesa','84 grs',1,'PEPSICO',16,4.45,6.95,8.28,'1',NULL,NULL),(35,'Galletas Barra sabor Coco','Gamesa','634 grs',1,'PEPSICO',45,36.74,39.16,43.00,'1',NULL,NULL),(36,'Quaker Barra Stila','Quaker','150 grs',1,'PEPSICO',87,20.00,22.63,26.39,'1',NULL,NULL),(37,'Sabritas Cheetos','Sabritas','45 grs',1,'PEPSICO',34,3.56,5.83,7.86,'1',NULL,NULL),(38,'Sabritas Ruffles','Sabritas','56 grs',1,'PEPSICO',83,6.45,8.55,10.45,'1',NULL,NULL),(39,'Galletas Bizcochitos','Gamesa','135 grs',1,'PEPSICO',94,5.20,7.62,9.12,'1',NULL,NULL),(40,'Avena Quaker Instant Fresas','Quaker','280 grs',1,'PEPSICO',36,30.12,32.18,37.40,'1',NULL,NULL),(41,'Galletas Maria minis','Gamesa','70 grs',1,'PEPSICO',83,4.56,6.20,8.56,'1',NULL,NULL),(42,'Gatorade Sport FresaSandia','Gatorade','600 ml',1,'PEPSICO',35,15.47,17.31,19.45,'1',NULL,NULL),(43,'Refresco Pepsi','Pepsi','2.5 lt',1,'PEPSICO',24,22.10,24.37,26.75,'1',NULL,NULL),(44,'Gatorade fresandia','Gatorade','1 lt',1,'PEPSICO',73,19.34,20.91,23.45,'1',NULL,NULL),(45,'Gatorade Uva','Gatorade','1 lt',1,'PEPSICO',76,18.12,20.91,23.45,'1',NULL,NULL),(46,'Gatorade Sport Limalimon','Gatorade','600 ml',1,'PEPSICO',31,12.45,17.30,20.13,'1',NULL,NULL),(47,'Gatorade ponche de futas','Gatorade','1 lt',1,'PEPSICO',93,15.34,20.91,22.34,'1',NULL,NULL),(48,'Gatorade Limalimon','Gatorade','1 lt',1,'PEPSICO',49,15.34,20.91,23.45,'1',NULL,NULL),(49,'Refresco Pepsi Kick','Pepsi','500 ml',1,'PEPSICO',94,5.45,8.83,10.67,'1',NULL,NULL),(50,'Refresco Seven Up','Seven Up','600 ml',1,'PEPSICO',27,7.38,9.53,11.25,'1',NULL,NULL),(51,'Flor de Naranjo','Gamesa','600 grs',1,'PEPSICO',36,40.23,43.33,45.78,'1',NULL,NULL),(52,'Caja Mamut','Gamesa','240 grs',1,'PEPSICO',35,18.34,21.31,24.10,'1',NULL,NULL),(53,'Galletas Maravillas','Gamesa','116 grs',1,'PEPSICO',91,5.27,9.00,11.26,'1',NULL,NULL),(54,'Leche Alpura Clasica azul','ALPURA','1 lt',2,'ALPURA',45,15.65,18.54,21.78,'1',NULL,NULL),(55,'Leche Alpura Deslactosada','ALPURA','1 lt',2,'ALPURA',57,17.45,19.08,22.30,'1',NULL,NULL),(56,'Leche Alpura Clasica','ALPURA','250 ml',2,'ALPURA',76,6.45,8.37,9.40,'1',NULL,NULL),(57,'Leche Alpura Deslactosada Light','ALPURA','1 lt',2,'ALPURA',25,16.75,19.25,22.96,'1',NULL,NULL),(58,'Leche Alpura Deslactosada','ALPURA','250 ml',2,'ALPURA',38,5.49,8.00,10.47,'1',NULL,NULL),(59,'Leche Fortileche','ALPURA','1 lt',2,'ALPURA',96,10.37,13.75,16.37,'1',NULL,NULL),(60,'Leche Alpura 2000 Light','ALPURA','1 lt',2,'ALPURA',84,15.90,18.33,20.00,'1',NULL,NULL),(61,'Leche Alpura Vainilla','ALPURA','250 ml',2,'ALPURA',74,5.45,7.24,8.40,'1',NULL,NULL),(62,'Leche Alpura Chocolate','ALPURA','250 ml',2,'ALPURA',94,5.10,7.17,10.56,'1',NULL,NULL),(63,'Leche Alpura Fresa','ALPURA','1 lt',2,'ALPURA',84,19.36,21.88,24.85,'1',NULL,NULL),(64,'Leche Alpura 2000','ALPURA','1 lt',2,'ALPURA',84,15.76,18.25,20.10,'1',NULL,NULL),(65,'Leche Alpura Polvo','ALPURA','500 grs',2,'ALPURA',84,60.39,62.50,65.93,'1',NULL,NULL),(66,'Leche Alpura Kids','ALPURA','1 lt',2,'ALPURA',56,18.84,21.00,23.76,'1',NULL,NULL),(67,'Leche Alpura Deslactosada Light','ALPURA','250 ml',2,'ALPURA',27,4.78,6.40,8.65,'1',NULL,NULL),(68,'Media Crema','ALPURA','250 ml',2,'ALPURA',20,8.56,10.35,12.49,'1',NULL,NULL),(69,'Leche Evaporada','ALPURA','376 grs',2,'ALPURA',63,10.36,13.82,15.67,'1',NULL,NULL),(70,'Leche Alpura Chocolate','ALPURA','1 lt',2,'ALPURA',77,19.85,21.88,23.89,'1',NULL,NULL),(71,'Leche Alpura Mujer','ALPURA','1 lt',2,'ALPURA',92,17.92,19.25,21.10,'1',NULL,NULL),(72,'Leche Alpura Vainilla','ALPURA','1 lt',2,'ALPURA',29,18.38,20.29,24.80,'1',NULL,NULL),(73,'Leche Alpura 40 y Tantos','ALPURA','1 lt',2,'ALPURA',38,16.09,18.00,20.12,'1',NULL,NULL),(74,'Leche Alpura Selecta','ALPURA','1 lt',2,'ALPURA',95,14.72,15.46,17.84,'1',NULL,NULL),(75,'Leche Alpura Semi','ALPURA','250 ml',2,'ALPURA',57,5.00,6.17,8.90,'1',NULL,NULL),(76,'Leche Alpura Fresa','ALPURA','250 ml',2,'ALPURA',37,4.95,7.17,9.29,'1',NULL,NULL),(77,'Producto lacteo en Polvo','Fortileche','500 grs',2,'ALPURA',36,45.20,48.85,51.19,'1',NULL,NULL),(78,'Ablandador de Carne','McCormick','992 grs',3,'HERDEZ',23,85.45,90.35,93.25,'1',NULL,NULL),(79,'Ajo en polvo','McCormick','595 grs',3,'HERDEZ',34,120.43,122.63,125.10,'1',NULL,NULL),(80,'Ajo granulado','McCormick','652 grs',3,'HERDEZ',46,140.20,143.20,145.45,'1',NULL,NULL),(81,'Atún en aceite','HERDEZ','295 grs',3,'HERDEZ',45,27.30,31.30,33.46,'1',NULL,NULL),(82,'Atún en aceite Lomo','HERDEZ','130 grs',3,'HERDEZ',23,15.37,18.46,23.56,'1',NULL,NULL),(83,'Atún en aceite','Nair','130 grs',3,'HERDEZ',21,11.90,13.75,16.86,'1',NULL,NULL),(84,'Atún en agua','HERDEZ','295 grs',3,'HERDEZ',93,28.65,31.29,34.76,'1',NULL,NULL),(85,'Atún en agua Lomo','HERDEZ','130 grs',3,'HERDEZ',56,15.43,17.39,19.28,'1',NULL,NULL),(86,'Atún en agua','Nair','130 grs',3,'HERDEZ',53,10.38,13.75,15.65,'1',NULL,NULL),(87,'Bebida Almejito','HERDEZ','220 ml',3,'HERDEZ',88,3.20,5.17,7.89,'1',NULL,NULL),(88,'Champiñon en trozos','HERDEZ','380 grs',3,'HERDEZ',62,22.40,25.62,28.75,'1',NULL,NULL),(89,'Champiñon entero','HERDEZ','186 grs',3,'HERDEZ',18,12.80,15.83,18.92,'1',NULL,NULL),(90,'Champiñon entero','HERDEZ','380 grs',3,'HERDEZ',28,26.61,28.45,31.95,'1',NULL,NULL),(91,'Champiñon rebanado','HERDEZ','186 grs',3,'HERDEZ',34,12.30,14.04,17.23,'1',NULL,NULL),(92,'Champiñon rebanado','HERDEZ','380 grs',3,'HERDEZ',23,22.45,26.08,28.97,'1',NULL,NULL),(93,'Champiñon rebanado','HERDEZ','800 grs',3,'HERDEZ',36,50.67,52.50,55.45,'1',NULL,NULL),(94,'Champiñon en trozos','HERDEZ','186 grs',3,'HERDEZ',82,10.23,13.50,15.85,'1',NULL,NULL),(95,'Chicharo','HERDEZ','215 grs',3,'HERDEZ',43,2.58,5.70,7.87,'1',NULL,NULL),(96,'Chile Jalapeño Entero','HERDEZ','200 grs',3,'HERDEZ',24,4.32,6.29,9.80,'1',NULL,NULL),(97,'Chicharo con Zanahoria','HERDEZ','400 grs',3,'HERDEZ',28,4.35,6.75,8.50,'1',NULL,NULL),(98,'Chicharo con Zanahoria','HERDEZ','400 grs',3,'HERDEZ',81,9.87,11.25,13.24,'1',NULL,NULL),(99,'Chicharo','HERDEZ','400 grs',3,'HERDEZ',25,5.23,9.85,11.27,'1',NULL,NULL),(100,'Coctel de Frutas en Almibar','HERDEZ','850 grs',3,'HERDEZ',53,47.36,49.55,52.90,'1',NULL,NULL),(101,'Mayonesa','McCormick','2.8 kg',3,'HERDEZ',20,150.45,155.75,159.56,'1',NULL,NULL),(102,'Pure de Tomate','Del Fuerte','345 grs',3,'HERDEZ',47,5.40,7.87,10.27,'1',NULL,NULL),(103,'Té de Manzanilla','McCormick','50 pq',3,'HERDEZ',57,25.67,27.70,30.10,'1',NULL,NULL),(104,'Duraznos en Almibar','HERDEZ','800 grs',3,'HERDEZ',62,40.35,43.33,47.86,'1',NULL,NULL),(105,'Ensalada Legumbres','HERDEZ','220 grs',3,'HERDEZ',34,4.30,6.83,9.50,'1',NULL,NULL),(106,'Ensalada Legumbres','HERDEZ','400 grs',3,'HERDEZ',32,8.10,10.81,12.32,'1',NULL,NULL),(107,'Ablandador de Carne','McCormick','155 grs',3,'HERDEZ',72,10.23,14.33,16.75,'1',NULL,NULL),(108,'Canela Molida','McCormick','63 grs',3,'HERDEZ',41,22.37,24.07,26.89,'1',NULL,NULL),(109,'Pimienta Blanca Molida','McCormick','66 grs',3,'HERDEZ',18,60.10,62.38,64.56,'1',NULL,NULL),(110,'Pimienta Negra Molida','McCormick','64 grs',3,'HERDEZ',27,40.38,43.13,46.59,'1',NULL,NULL),(111,'Sal con Ajo','McCormick','157 grs',3,'HERDEZ',63,15.34,17.00,19.34,'1',NULL,NULL),(112,'Sal con Cebolla','McCormick','126 grs',3,'HERDEZ',52,13.56,15.70,18.56,'1',NULL,NULL),(113,'Granos de Elote','HERDEZ','220 grs',3,'HERDEZ',53,5.90,7.62,9.75,'1',NULL,NULL),(114,'Granos de Elote','HERDEZ','400 grs',3,'HERDEZ',26,10.20,12.47,15.60,'1',NULL,NULL),(115,'Jarabe Maple','McCormick','235 ml',3,'HERDEZ',23,20.17,21.25,25.30,'1',NULL,NULL),(116,'Jarabe Maple Fresa','McCormick','235 ml',3,'HERDEZ',18,19.65,21.65,24.34,'1',NULL,NULL),(117,'Jarabe Maple sin Azucar','McCormick','235 ml',3,'HERDEZ',24,20.17,22.15,24.71,'1',NULL,NULL),(118,'Jugo 8 Verduras Lata','HERDEZ','235 ml',3,'HERDEZ',24,6.75,8.14,10.45,'1',NULL,NULL),(119,'Mayonesa Light Squeeze','McCormick','350 grs',3,'HERDEZ',25,19.86,21.55,24.76,'1',NULL,NULL),(120,'Mayonesa','McCormick','390 grs',3,'HERDEZ',84,24.56,26.91,28.96,'1',NULL,NULL),(121,'Mayonesa','McCormick','725 grs',3,'HERDEZ',14,42.30,44.00,47.61,'1',NULL,NULL),(122,'Mayonesa','McCormick','105 grs',3,'HERDEZ',21,8.96,10.20,13.24,'1',NULL,NULL),(123,'Mayonesa','McCormick','190 grs',3,'HERDEZ',35,13.25,15.87,18.56,'1',NULL,NULL),(124,'Mayonesa Reducida en Grasa','McCormick','390 grs',3,'HERDEZ',45,18.45,22.09,24.90,'1',NULL,NULL),(125,'Mayonesa Squeeze Chipotle','McCormick','350 grs',3,'HERDEZ',27,18.75,21.32,25.76,'1',NULL,NULL),(126,'Mayonesa Squeeze','McCormick','320 grs',3,'HERDEZ',45,18.95,21.20,25.78,'1',NULL,NULL),(127,'Mermelada Chabacano','McCormick','270 grs',3,'HERDEZ',32,15.30,18.32,22.35,'1',NULL,NULL),(128,'Mermelada Chabacano','McCormick','500 grs',3,'HERDEZ',73,27.65,30.73,33.56,'1',NULL,NULL),(129,'Mermelada Piña','McCormick','500 grs',3,'HERDEZ',28,28.50,30.00,34.90,'1',NULL,NULL),(130,'Mermelada Zarzamora','McCormick','500 grs',3,'HERDEZ',35,28.95,30.73,35.67,'1',NULL,NULL),(131,'Mermelada Durazno','McCormick','270 ml',3,'HERDEZ',28,15.30,18.32,22.35,'1',NULL,NULL),(132,'Mermelada Fresa','McCormick','270 grs',3,'HERDEZ',46,13.78,15.83,18.54,'1',NULL,NULL),(133,'Mermelada Fresa','McCormick','450 grs',3,'HERDEZ',74,20.34,23.68,26.76,'1',NULL,NULL),(134,'Mermelada Fresa','McCormick','980 grs',3,'HERDEZ',37,44.37,46.53,48.98,'1',NULL,NULL),(135,'Mermelada Naranja','McCormick','270 grs',3,'HERDEZ',35,15.30,18.32,22.35,'1',NULL,NULL),(136,'Mermelada Piña','McCormick','270 grs',3,'HERDEZ',52,15.30,18.32,22.35,'1',NULL,NULL),(137,'Mermelada Zarzamora','McCormick','270 grs',3,'HERDEZ',54,15.30,18.32,22.35,'1',NULL,NULL),(138,'Miel Carlota','Carlota','300 ml',3,'HERDEZ',52,34.58,37.65,40.45,'1',NULL,NULL),(139,'Miel Carlota','Carlota','500 ml',3,'HERDEZ',42,53.00,54.51,58.95,'1',NULL,NULL),(140,'Mole Tetrapack','Doña Maria','540 grs',3,'HERDEZ',25,15.40,18.88,23.80,'1',NULL,NULL),(141,'Mole Rojo','Doña Maria','125 grs',3,'HERDEZ',24,10.24,14.11,19.70,'1',NULL,NULL),(142,'Mole Rojo','Doña Maria','235 grs',3,'HERDEZ',35,22.37,25.49,29.80,'1',NULL,NULL),(143,'Mole Rojo','Doña Maria','375 grs',3,'HERDEZ',74,34.56,37.08,39.90,'1',NULL,NULL),(144,'Mole Verde','Doña Maria','230 grs',3,'HERDEZ',82,22.38,27.13,33.29,'1',NULL,NULL),(145,'Mostaza','Mccormick','115 grs',3,'HERDEZ',48,5.78,8.16,12.35,'1',NULL,NULL),(146,'Mostaza','Mccormick','210 grs',3,'HERDEZ',28,8.40,10.74,13.78,'1',NULL,NULL),(147,'Mostaza Dosificada','Mccormick','260 ml',3,'HERDEZ',35,10.45,15.67,17.80,'1',NULL,NULL),(148,'Mostaza Squeze','Mccormick','360 ml',3,'HERDEZ',72,17.34,20.34,24.50,'1',NULL,NULL),(149,'Papel Aluminio','Reynolds Wrap','7.6 mt',3,'HERDEZ',17,20.65,24.70,28.56,'1',NULL,NULL),(150,'Pimiento Morron en Tiras','Mccormick','185 grs',3,'HERDEZ',35,12.40,14.58,18.23,'1',NULL,NULL),(151,'Pimienton','Mccormick','510 grs',3,'HERDEZ',28,110.30,117.53,124.56,'1',NULL,NULL),(152,'Piña Trozos','HERDEZ','800 grs',3,'HERDEZ',28,36.79,40.50,45.80,'1',NULL,NULL),(153,'Pure Tomate Condimentado Tetrapak','Del Fuerte','1 litro',3,'HERDEZ',34,14.90,19.78,24.67,'1',NULL,NULL),(154,'Pure Tomate','HERDEZ','210 ml',3,'HERDEZ',49,2.10,4.35,7.30,'1',NULL,NULL),(155,'Pure Tomate','HERDEZ','345 ml',3,'HERDEZ',78,3.40,5.75,9.80,'1',NULL,NULL),(156,'Salsa Casera','HERDEZ','210 grs',3,'HERDEZ',89,3.67,7.39,11.23,'1',NULL,NULL),(157,'Salsa Catsup Embasa','Del Fuerte','1 kg',3,'HERDEZ',39,13.67,18.25,22.35,'1',NULL,NULL),(158,'Té 7 Azahares','Mccormick','25 sobres',3,'HERDEZ',39,18.50,20.62,24.56,'1',NULL,NULL),(159,'Té Canela Manzana','Mccormick','25 sobres',3,'HERDEZ',73,10.40,15.62,18.45,'1',NULL,NULL),(160,'Té Canela','Mccormick','25 sobres',3,'HERDEZ',38,19.30,21.45,25.67,'1',NULL,NULL),(161,'Té Hierbabuena','Mccormick','25 sobres',3,'HERDEZ',20,20.56,24.58,28.00,'1',NULL,NULL),(162,'Té Limon','Mccormick','25 sobres',3,'HERDEZ',55,10.25,15.83,19.80,'1',NULL,NULL),(163,'Té Limón','Mccormick','50 sobres',3,'HERDEZ',87,23.67,28.79,32.78,'1',NULL,NULL),(164,'Té Manzanilla','Mccormick','25 sobres',3,'HERDEZ',19,14.38,16.25,23.92,'1',NULL,NULL),(165,'Té Tila','Mccormick','25 sobres',3,'HERDEZ',23,19.82,21.41,23.84,'1',NULL,NULL),(166,'Té Verde','Mccormick','25 sobres',3,'HERDEZ',68,20.45,25.83,27.90,'1',NULL,NULL),(167,'Café con canela','Legal','200 grs',13,'SABORMEX',28,25.67,28.81,34.50,'1',NULL,NULL),(168,'Salsa Catsup','Clemente Jacques','220 grs',13,'SABORMEX',43,5.78,7.91,11.27,'1',NULL,NULL),(169,'Mermelada de Fresa','Clemente Jaques','270 grs',13,'SABORMEX',66,10.55,13.29,16.93,'1',NULL,NULL),(170,'Café soluble frasco','Legal','50 grs',13,'SABORMEX',54,12.76,16.83,20.40,'1',NULL,NULL),(171,'Frijol Refrito Bayo','La Sierra','580 grs',13,'SABORMEX',28,10.37,13.60,17.89,'1',NULL,NULL),(172,'Frijol Negro Refrito','La Sierra','580 grs',13,'SABORMEX',47,10.56,13.15,17.93,'1',NULL,NULL),(173,'Frijol Bayo Refrito','La Sierra','440 grs',13,'SABORMEX',47,10.10,12.63,18.79,'1',NULL,NULL),(174,'Frijol Bayo Entero','La Sierra','560 grs',13,'SABORMEX',53,10.30,12.16,16.30,'1',NULL,NULL),(175,'Vinagre Blanco','Clemente Jacques','1 litro',13,'SABORMEX',64,8.65,10.00,14.34,'1',NULL,NULL),(176,'Café tradicional bolsa','Legal','400 grs',13,'SABORMEX',18,48.45,52.29,54.67,'1',NULL,NULL),(177,'Café Soluble Sobre','Legal','10 grs',13,'SABORMEX',28,10.56,14.49,16.76,'1',NULL,NULL),(178,'Frijol Negro Entero','La Sierra','560 grs',13,'SABORMEX',26,8.76,11.46,13.56,'1',NULL,NULL),(179,'Chiles Rajas Rojas','Clemente Jacques','220 grs',13,'SABORMEX',92,5.68,7.38,9.10,'1',NULL,NULL),(180,'Chiles Jalapeños','Clemente Jacques','220 grs',13,'SABORMEX',84,4.78,6.53,8.90,'1',NULL,NULL),(181,'Chiles Habanero Molidos','Clemente Jacques','220 grs',13,'SABORMEX',64,18.93,20.49,23.48,'1',NULL,NULL),(182,'Bebida uva','Enerplex','600 ml',13,'SABORMEX',72,9.67,11.25,13.56,'1',NULL,NULL),(183,'Bebida mandarina','Enerplex','600 ml',13,'SABORMEX',27,9.80,11.25,13.54,'1',NULL,NULL),(184,'Aderezo césar','Clemente Jacques','237 ml',13,'SABORMEX',84,14.67,17.63,19.56,'1',NULL,NULL),(185,'Frijol Bayo Pounch','La Sierra','220 grs',13,'SABORMEX',28,4.60,6.91,9.45,'1',NULL,NULL),(186,'Salsa Catsup','Clemente Jacques','390 grs',13,'SABORMEX',73,9.87,11.02,13.45,'1',NULL,NULL),(187,'Bebida limón','Enerplex','600 ml',13,'SABORMEX',46,9.34,11.25,13.53,'1',NULL,NULL),(188,'Bebida sabor naranja','Enerplex','600 ml',13,'SABORMEX',78,8.65,11.25,14.63,'1',NULL,NULL),(189,'Salsa Tipo Catsup Squeeze','Clemente Jacques','680 ml',13,'SABORMEX',18,20.47,23.08,25.67,'1',NULL,NULL),(190,'Granos de Elote','Clemente Jacques','410 grs',13,'SABORMEX',29,10.00,12.17,13.56,'1',NULL,NULL),(191,'Chicharo con Zanahoria','Clemente Jacques','220 grs',13,'SABORMEX',83,4.68,6.11,9.87,'1',NULL,NULL),(192,'Frijol con Chorizo','La Sierra','440 grs',13,'SABORMEX',22,10.45,13.65,16.75,'1',NULL,NULL),(193,'Frijoles con Queso','La Sierra','440 grs',13,'SABORMEX',38,10.45,13.31,16.74,'1',NULL,NULL),(194,'Chipotles Molidos','Clemente Jacques','220 grs',13,'SABORMEX',84,12.30,15.44,18.10,'1',NULL,NULL),(195,'Café Descafeinado','Legal','180 grs',13,'SABORMEX',38,50.17,54.16,58.90,'1',NULL,NULL),(196,'Mermelada de Fresa','Clemente Jacques','470 grs',13,'SABORMEX',37,20.48,23.16,26.73,'1',NULL,NULL),(197,'Vinagre Blanco','Clemente Jacques','500 ml',13,'SABORMEX',37,5.67,7.41,9.80,'1',NULL,NULL),(198,'Frijol Charro','La Sierra','560 grs',13,'SABORMEX',83,10.48,14.35,18.00,'1',NULL,NULL),(199,'Frijol Bayo Refrito Bolsa','La Sierra','430 grs',13,'SABORMEX',73,8.76,11.61,13.56,'1',NULL,NULL),(200,'Chiles Rajas','Clemente Jacques','220 grs',13,'SABORMEX',29,4.78,7.50,10.58,'1',NULL,NULL),(201,'Chi­charo','Clemente Jacques','220 grs',13,'SABORMEX',94,4.10,6.60,9.81,'1',NULL,NULL),(202,'Café Soluble','Oro','50 grs',13,'SABORMEX',9,15.89,18.55,22.34,'1',NULL,NULL),(203,'Bebida blueberry','Enerplex','600 ml',13,'SABORMEX',37,9.84,11.25,13.90,'1',NULL,NULL),(204,'Aderezo Ranch','Clemente Jacques','237 grs',13,'SABORMEX',48,15.67,17.58,20.45,'1',NULL,NULL),(205,'Detergente','Roma','1kg',14,'LA CORONA',8,24.59,28.10,30.26,'1',NULL,NULL),(206,'Detergente','Roma','500grs',14,'LA CORONA',11,10.45,14.15,17.89,'1',NULL,NULL),(207,'Aceite','1-2-3','1 litro',14,'LA CORONA',43,22.00,26.66,29.78,'1',NULL,NULL),(208,'Detergente','Roma','250grs',14,'LA CORONA',49,5.10,7.06,9.18,'1',NULL,NULL),(209,'Aceite','1-2-3','500 ml',14,'LA CORONA',48,10.34,13.00,16.39,'1',NULL,NULL),(210,'Detergente Liquido','Roma','1 litro',14,'LA CORONA',88,18.34,20.25,23.56,'1',NULL,NULL),(211,'Jabón de Tocador Rosa','Rosa Venus','25 grs',14,'LA CORONA',27,0.50,1.16,4.67,'1',NULL,NULL),(212,'Jabon de Lavanderia Rosa','Zote','400 grs',14,'LA CORONA',28,10.45,13.48,16.67,'1',NULL,NULL),(213,'Detergente','Blanca Nieves','500 grs',14,'LA CORONA',10,10.34,13.75,17.60,'1',NULL,NULL),(214,'Detergente','Blanca Nieves','250 grs',14,'LA CORONA',32,4.36,6.87,9.67,'1',NULL,NULL),(215,'Detergente en polvo  bolsa','Roma','10kgs',14,'LA CORONA',68,270.40,278.50,281.34,'1',NULL,NULL),(216,'Jabón de Tocador Blanco','Rosa Venus','25 grs',14,'LA CORONA',74,0.50,1.16,4.67,'1',NULL,NULL),(217,'Detergente','Blanca Nieves','1kg',14,'LA CORONA',9,24.93,27.40,30.29,'1',NULL,NULL),(218,'Jabón Lavanderia Blanco','Zote','100 grs',14,'LA CORONA',27,2.10,3.51,6.94,'1',NULL,NULL),(219,'Jabón de Lavanderia Blanco','Zote','400 grs',14,'LA CORONA',75,11.50,13.48,18.45,'1',NULL,NULL),(220,'Detergente','Foca','500grs',14,'LA CORONA',93,12.56,15.39,18.95,'1',NULL,NULL),(221,'Detergente','Foca','1 kg',14,'LA CORONA',27,27.56,30.40,33.67,'1',NULL,NULL),(222,'Jabón de Tocador Blanco','Rosa Venus','100 grs',14,'LA CORONA',93,2.40,4.35,6.80,'1',NULL,NULL),(223,'Bolsa de detergente','Blanca Nieves','10 kilos',14,'LA CORONA',37,260.00,266.00,268.00,'1',NULL,NULL),(224,'Jabón de Tocador neutro','Tersso','200 grs',14,'LA CORONA',83,6.50,9.00,12.36,'1',NULL,NULL),(225,'Detergente','Foca','250 grs',14,'LA CORONA',39,4.38,7.37,9.82,'1',NULL,NULL),(226,'Jabón de Lavanderia Rosa','Zote','200 grs',14,'LA CORONA',90,4.67,6.84,8.91,'1',NULL,NULL),(227,'Jabón de Tocador','Manilva Herbal','150 grs',14,'LA CORONA',86,4.79,6.25,9.87,'1',NULL,NULL),(228,'Jabón de Tepeyac','Tepeyac','200 grs',14,'LA CORONA',19,5.78,8.83,10.67,'1',NULL,NULL),(229,'Suavizante Galon','Carisma','3.785 litros',14,'LA CORONA',28,64.57,67.25,69.10,'1',NULL,NULL),(230,'Jabón en barra con envoltura color amarillo','Corona','400grs',14,'LA CORONA',28,9.90,12.50,14.56,'1',NULL,NULL),(231,'Jabón Lila','Tepeyac','200 grs',14,'LA CORONA',92,5.89,7.83,9.78,'1',NULL,NULL),(232,'Jabón Rosa','Tepeyac','200 grs',14,'LA CORONA',84,6.78,8.83,10.20,'1',NULL,NULL),(233,'Jabón azul','Coral','150 grs',14,'LA CORONA',49,4.67,6.65,9.80,'1',NULL,NULL),(234,'Jabón líquido','Rosa Venus','500 ml',14,'LA CORONA',29,14.56,16.75,19.80,'1',NULL,NULL),(235,'Suavizante','Carisma','1 litro',14,'LA CORONA',10,14.58,18.82,21.36,'1',NULL,NULL),(236,'Limpiador Lila','Colibri','1 litro',14,'LA CORONA',93,12.56,14.25,17.90,'1',NULL,NULL),(237,'Jabón Escamas','Zote','500 grs',14,'LA CORONA',27,23.48,26.56,29.90,'1',NULL,NULL),(238,'Lavastrastes','Briloza','1kg',14,'LA CORONA',39,20.56,25.10,28.85,'1',NULL,NULL),(239,'Jabón Verde','Tepeyac','200 grs',14,'LA CORONA',37,5.89,7.83,9.90,'1',NULL,NULL),(240,'Jabón rosa','Coral','150 grs',14,'LA CORONA',27,4.67,6.14,8.95,'1',NULL,NULL),(241,'Jabón beige','Coral','150 grs',14,'LA CORONA',46,4.78,6.52,10.60,'1',NULL,NULL),(242,'Detergente','Puro Sol','250 grs',14,'LA CORONA',73,5.78,6.40,8.96,'1',NULL,NULL),(243,'Detergente','Puro Sol','500 grs',14,'LA CORONA',17,10.56,12.80,14.67,'1',NULL,NULL),(244,'Detergente','Puro Sol','1 kilo',14,'LA CORONA',27,20.56,25.45,28.95,'1',NULL,NULL),(245,'Limpiador Lila','Colibri','1 litro',14,'LA CORONA',78,10.57,13.75,17.89,'1',NULL,NULL),(246,'Limpiador Azul','Colibri','1 litro',14,'LA CORONA',36,10.50,13.00,17.89,'1',NULL,NULL),(247,'Limpiador Amarillo','Colibri','1 litro',14,'LA CORONA',94,10.50,13.00,17.89,'1',NULL,NULL),(248,'Limpiador Rosa','Colibri','1 litro',14,'LA CORONA',25,9.69,12.40,16.40,'1',NULL,NULL),(249,'Limpiador Amarillo','Colibri','500 ml',14,'LA CORONA',68,4.78,7.58,10.56,'1',NULL,NULL),(250,'Limpiador Azul','Colibri','500 ml',14,'LA CORONA',15,4.78,7.58,10.56,'1',NULL,NULL),(251,'Limpiador Rosa','Colibri','500 ml',14,'LA CORONA',95,4.78,7.18,10.56,'1',NULL,NULL),(252,'Lavatrastes','Briloza','500 grs',14,'LA CORONA',26,10.45,12.90,15.80,'1',NULL,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_provider` varchar(60) NOT NULL,
  `num_contact` varchar(10) NOT NULL,
  `email` varchar(60) NOT NULL,
  `address` varchar(120) NOT NULL,
  `flag` varchar(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providers`
--

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
INSERT INTO `providers` VALUES (1,'PEPSICO','9512784445','pep1995@gmail.com','Colonia Reforma Jazmines #105','1',NULL,'2018-06-06 08:31:42'),(2,'ALPURA','9513965274','alp@gmail.com','Vicente Guerrero 112 Centro','1',NULL,NULL),(3,'HERDEZ','9512746374','gerdoax@gmail.com','Av. de las Etnias 509, Col. Olimpica','1',NULL,NULL),(4,'LA COSTEÑA','9518607384','costemex@gmail.com','Calle Soconusco No. 214-A, Col. Volcanes','1',NULL,NULL),(5,'LA MODERNA','9512007968','modern23@gmail.com','Calle de Libres No. 113, Col. Centro','1',NULL,NULL),(6,'COLGATE-PALMOLIVE','9517867898','colpaloax@gmail.com','Calzada Porfirio Díaz #307,Col. Reforma','1',NULL,NULL),(7,'Kimberly Clark','9519684788','kimc@gmail.com','Gardenias No.124, Col. Reforma','1',NULL,NULL),(8,'SCA','9512327463','sca88@gmail.com','NIÑOS HEROES 500, EX-MARQUEZADO','1',NULL,NULL),(9,'Fabrica de Papel San Francisco','9512356456','fbpp@gmail.com','BLVD EDUARDO MATA 1421, BARRIO TRINIDAD DE LAS HUERTAS','1',NULL,NULL),(10,'PI Mabe','9512375483','pimb@gmail.com','CLL H COLEGIO MILITAR 525, REFORMA','1',NULL,NULL),(11,'ML','9514576787','mlcomp@gmail.com','INDEPENDENCIA 1404, CENTRO','1',NULL,NULL),(12,'FAQ','9512556438','faqoax@gmail.com','PRV TRUJANO 121, CENTRO','1',NULL,NULL),(13,'SABORMEX','9511842654','sabmex@gmail.com','CLL MANUEL GARCIA VIGIL 602, LA SOLEDAD','1',NULL,NULL),(14,'LA CORONA','9511052846','corona@gmail.com','CLL 20 DE NOVIEMBRE 921, CENTRO','1',NULL,NULL),(15,'Procter & Gamble','951849573','proct@gmail.com','CALZ PORFIRIO DIAZ 243 - A, REFORMA','1',NULL,NULL),(16,'UNILEVER','9517465838','unicompany@gmail.com','Calle La Constitucion # 108 Centro','0',NULL,'2018-06-05 07:19:17'),(17,'bimbo','43757','ingridera.pao@gmail.com','fegwfyew','1','2018-06-06 19:26:43','2018-06-06 19:26:43');
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale__products`
--

DROP TABLE IF EXISTS `sale__products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale__products` (
  `sales_id` int(10) unsigned NOT NULL,
  `products_id` int(10) unsigned NOT NULL,
  `quantyti_product` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `sales_products_sales_id_foreign` (`sales_id`),
  KEY `sales_products_products_id_foreign` (`products_id`),
  CONSTRAINT `sales_products_products_id_foreign` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`),
  CONSTRAINT `sales_products_sales_id_foreign` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale__products`
--

LOCK TABLES `sale__products` WRITE;
/*!40000 ALTER TABLE `sale__products` DISABLE KEYS */;
INSERT INTO `sale__products` VALUES (2,1,2,NULL,NULL),(2,2,1,NULL,NULL),(2,3,1,NULL,NULL),(3,4,3,NULL,NULL),(5,3,5,'2018-04-06 06:14:50','2018-04-06 06:14:50'),(5,4,1,'2018-04-06 06:14:50','2018-04-06 06:14:50');
/*!40000 ALTER TABLE `sale__products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `flag` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_user_id_foreign` (`user_id`),
  CONSTRAINT `sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,6,'1',NULL,NULL),(2,6,'1',NULL,NULL),(3,6,'1',NULL,NULL),(4,6,'1',NULL,NULL),(5,8,'1','2018-04-06 06:14:49','2018-04-06 06:14:49');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'edwin1','$2y$10$ZQAIG2eBHwVEm8GZ/2yoq.0HGaXYIwMinknROq.jaVwnBc0p2EmAi','administrador','YGybQa6DXZgyI6hqLQNMcdK80vUiJ5TH6822pBrI92kPg3I1Y4zLWzRIqSPH','0',NULL,'2018-06-05 05:48:55'),(2,'gibran1','$2y$10$ZQAIG2eBHwVEm8GZ/2yoq.0HGaXYIwMinknROq.jaVwnBc0p2EmAi','administrador',NULL,'0',NULL,'2018-06-05 05:49:03'),(3,'brenda1','$2y$10$ZQAIG2eBHwVEm8GZ/2yoq.0HGaXYIwMinknROq.jaVwnBc0p2EmAi','administrador',NULL,'0',NULL,'2018-06-05 05:49:07'),(4,'paola','$2y$10$0xWlEEtiUa0Vsc2dTr6.qe3iQ6RCzbJifwCPCzo4WgbeKvbQxause','administrador','sbHUBHblWLFquIhCN5FQiFOkkgtzTVn6T1eIpqCc7iUqLQLuzeJnfUM4nrMQ','1',NULL,'2018-06-05 06:32:45'),(5,'Juan','$2y$10$ZQAIG2eBHwVEm8GZ/2yoq.0HGaXYIwMinknROq.jaVwnBc0p2EmAi','administrador',NULL,'1',NULL,NULL),(6,'Jose','$2y$10$ZQAIG2eBHwVEm8GZ/2yoq.0HGaXYIwMinknROq.jaVwnBc0p2EmAi','jefeAlmacen',NULL,'1',NULL,NULL),(7,'alejandra','$2y$10$v.Mi84fsCqlpdQYXJmxDiexpzIlwtPd.hMquzRgGmQoiV75PP297u','administrador','vavzhNmi6HeTJ1nuoWL9w2O0AQTgeZCUFExrVmGssvms8JMNdLxtRXUKfXpb','1','2018-04-06 06:10:52','2018-04-06 06:10:52'),(8,'gregorio','$2y$10$iWRB28qGtdX.0TKbABSL3eN9/16iHSuMbTPvKvXJ/3S5VsYE7b6mi','jefeAlmacen','dAJYHyL62t9VQZu5eJYSaMHw4StHBVE8OtFKdu7E1pou3dGN8suqDt0JshXX','1','2018-04-06 06:12:46','2018-04-06 06:12:46'),(9,'hola','$2y$10$nW0VAkTddEror0/QtgVDueJ.cHNm7jWFlv5t787URb2v4Qp8bGJPO','administrador',NULL,'0','2018-06-04 16:32:15','2018-06-05 05:49:17'),(10,'cita','$2y$10$qfVF4cZxhng7VHagW/99QOhN8wETTIyhB44AMhLVOCGJnHSppD.yS','administrador',NULL,'0','2018-06-04 17:24:08','2018-06-05 07:24:18'),(11,'adriana','$2y$10$PSUfxHUtgXvv2W6gJ6pE7uVQ6VJJy8PG2y/kQ2jmaxxREIXQZtShu','vendedor','j5gwYuuWJRQgEQuC1WnJxOCO1HFaBk6AiePmzI8yMN3NZ6QCnGsaWbDuos2k','0','2018-06-05 06:11:26','2018-06-06 19:36:51'),(12,'hola2','$2y$10$XLsZPcX.2WxMZ2MJugzl2eZ8mSayuQGrLt1pJAajvlQdu62kR9Plu','jefeAlmacen',NULL,'0','2018-06-05 19:42:27','2018-06-05 19:42:57'),(13,'citlally','$2y$10$c2mjFLIEe4zw07rgW3z7r.KFpls7mtsIecsuT2CfDGe9OAuQjl4yG','jefe_almacen',NULL,'1','2018-06-06 19:55:55','2018-06-06 19:57:55'),(14,'ola','$2y$10$4vYejyD2JeHNZIZnG06Bx.I5ra7aLlxBVWRLtP7JKknfsJyfkz5O.','jefeAlmacen',NULL,'1','2018-06-07 07:39:57','2018-06-07 07:39:57'),(15,'paola2','$2y$10$ECpzK3hf1gb7nN0j4p6YT./1gWXNwANqkFCxw4COR.A8yuBr1uLke','administrador',NULL,'1','2018-06-07 19:28:10','2018-06-07 19:28:10');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-09 14:28:56
